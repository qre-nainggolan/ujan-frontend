process.env.REACT_APP_API_URL = "http://localhost:9009/api";

import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import QuestionForm from "../QuestionForm";
import { ToastContainer } from "react-toastify";
import axios from "axios";

axios.defaults.baseURL =
  process.env.REACT_APP_API_URL || "http://localhost:9009/api";

import agent from "../../../app/api/agent";

// test("direct axios call", async () => {
//   const res = await axios.get("http://localhost:9009/api/package/get-package");
//   console.log("direct call result:", res.status, res.data);
// });
const fetchRealPackages = async () => {
  console.log(
    "✅ Available keys in agent.Package:",
    Object.keys(agent.Package)
  );

  try {
    console.log("JEST axios baseURL =", axios.defaults.baseURL);
    const result = await agent.Package.getPackageTest(); // already the array

    if (!Array.isArray(result) || result.length === 0) {
      console.error("Fetched package list is empty or invalid:", result);
      return [];
    }

    return result;
  } catch (err) {
    console.error("Real agent fetch failed:", err);
    return [];
  }
};

describe("QuestionForm Component with real agent data", () => {
  it("renders and submits form using real package data", async () => {
    const realPackages = await fetchRealPackages();
    expect(realPackages.length).toBeGreaterThan(0);

    render(
      <MemoryRouter>
        <QuestionForm initialPackages={realPackages} />
        <ToastContainer />
      </MemoryRouter>
    );

    // Wait for the package name to appear
    await screen.findByText(new RegExp(realPackages[0].name, "i"));

    fireEvent.change(screen.getByLabelText(/Paket/i), {
      target: { value: realPackages[0].package_id },
    });

    fireEvent.change(screen.getByLabelText(/Text Pertanyaan/i), {
      target: { value: "What is 5 + 5?" },
    });

    fireEvent.change(screen.getByLabelText(/Type/i), {
      target: { value: "TIU" },
    });

    fireEvent.change(screen.getByLabelText(/Option A/i), {
      target: { value: "9" },
    });

    fireEvent.change(screen.getByLabelText(/Option B/i), {
      target: { value: "10" },
    });

    fireEvent.click(screen.getByLabelText("B"));
    fireEvent.click(screen.getByText(/Kirim Pertanyaan/i));

    const confirmButton = await screen.findByTestId("submit-confirm");
    fireEvent.click(confirmButton);

    await waitFor(() =>
      expect(
        screen.getByText(/Pertanyaan berhasil ditambahkan!/i)
      ).toBeInTheDocument()
    );
  });
});
