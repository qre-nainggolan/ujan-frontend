import "../../css/style2.css";
import "../../css/grid.css";
import "../../css/form.css";
import "../../css/style_popup.css";
import { useEffect, useState, useMemo } from "react";
import NavLane from "../../NavLane";
import Footer from "../../Footer";
import Header from "../../Header";
import agent from "../../app/api/agent";
import DataGrid from "../component/DataGrid";
import Plotly from "plotly.js-dist-min";
import { CONFIG } from "../../config/millConfig";

type UptimeMonitoring_ = {
  Mill: string;
  Code: string;
  1: number;
  2: number;
  3: number;
  4: number;
  5: number;
  6: number;
  7: number;
  8: number;
  9: number;
  10: number;
  11: number;
  12: number;
  13: number;
  14: number;
  15: number;
  16: number;
  17: number;
  18: number;
  19: number;
  20: number;
  21: number;
  22: number;
  23: number;
  24: number;
  25: number;
  26: number;
  27: number;
  28: number;
  29: number;
  30: number;
  31: number;
  total: number;
};

type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  group?: string; // ✅ NEW: for grouping headers
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left";
  width?: number;
  wrap?: boolean;
};

function UptimeMonitoring() {
  const [mill, setMill] = useState("PSG");
  const [year, setYear] = useState(2025);
  const [month, setMonth] = useState(11);
  const [data, setData] = useState<UptimeMonitoring_[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalData, setTotalData] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [pageSize, setPageSize] = useState(50);
  const [popupClass, setPopupclass] = useState("popup");
  const [isLoading, setIsLoading] = useState(true);

  // inside UptimeMonitoring()
  const labelByKey = useMemo(() => {
    const series =
      CONFIG[mill as keyof typeof CONFIG]?.groups.flatMap((g) => g.series) ??
      [];
    return Object.fromEntries(series.map((s) => [s.key, s.label ?? s.key]));
  }, [mill]);

  const sensorDataColumn: ColumnDefinition<UptimeMonitoring_>[] = [
    {
      header: "#",
      key: "row_index",
      render: (_: UptimeMonitoring_, i: number) =>
        i + 1 + (currentPage - 1) * pageSize,
      align: "left",
      width: 11,
    },
    {
      header: "Sensor Code",
      key: "Code",
      wrap: true,
      width: 75,
      render: (row: UptimeMonitoring_) => labelByKey[row.Code] ?? row.Code,
    },
    { header: "1", key: "1", width: 55, align: "right" },
    { header: "2", key: "2", width: 55, align: "right" },
    { header: "3", key: "3", width: 55, align: "right" },
    { header: "4", key: "4", width: 55, align: "right" },
    { header: "5", key: "5", width: 55, align: "right" },
    { header: "6", key: "6", width: 55, align: "right" },
    { header: "7", key: "7", width: 55, align: "right" },
    { header: "8", key: "8", width: 55, align: "right" },
    { header: "9", key: "9", width: 55, align: "right" },
    { header: "10", key: "10", width: 55, align: "right" },
    { header: "11", key: "11", width: 55, align: "right" },
    { header: "12", key: "12", width: 55, align: "right" },
    { header: "13", key: "13", width: 55, align: "right" },
    { header: "14", key: "14", width: 55, align: "right" },
    { header: "15", key: "15", width: 55, align: "right" },
    { header: "16", key: "16", width: 55, align: "right" },
    { header: "17", key: "17", width: 55, align: "right" },
    { header: "18", key: "18", width: 55, align: "right" },
    { header: "19", key: "19", width: 55, align: "right" },
    { header: "20", key: "20", width: 55, align: "right" },
    { header: "21", key: "21", width: 55, align: "right" },
    { header: "22", key: "22", width: 55, align: "right" },
    { header: "23", key: "23", width: 55, align: "right" },
    { header: "24", key: "24", width: 55, align: "right" },
    { header: "25", key: "25", width: 55, align: "right" },
    { header: "26", key: "26", width: 55, align: "right" },
    { header: "27", key: "27", width: 55, align: "right" },
    { header: "28", key: "28", width: 55, align: "right" },
    { header: "29", key: "29", width: 55, align: "right" },
    { header: "30", key: "30", width: 55, align: "right" },
    { header: "31", key: "31", width: 55, align: "right" },
    { header: "Total", key: "total", width: 55, align: "right" },
  ];

  const fetchData = async (mill_: string, year_: number, month_: number) => {
    setIsLoading(true);
    try {
      await agent.Lora.getUptimeMonitoring(mill_, year_, month_).then(
        (response) => {
          setData(response.data); // response.data.rows if using { rows, total }
        }
      );
    } catch (err) {
      console.error("err : " + err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData(mill, year, month);
  }, [mill, year, month]);

  // Close button and popup logic
  const closeBtn = document.querySelector(".popup__close") as HTMLElement;
  const popup = document.getElementById("popup") as HTMLElement;

  closeBtn?.addEventListener("click", () => {
    setPopupclass("popup");
    Plotly.purge("curveChart");
  });

  window.addEventListener("click", (event) => {
    if (event.target === popup) {
      setPopupclass("popup");
      Plotly.purge("curveChart");
    }
  });

  return (
    <>
      <div className="layout">
        <Header />
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <div className="sensor-container">
              <div className="controls">
                <select
                  value={mill}
                  onChange={(e) => setMill(e.target.value)}
                  className="selection__input"
                >
                  <option value="">Select Mill</option>
                  <option value="PAN">PAN</option>
                  <option value="PSG">PSG</option>
                </select>
                <select
                  value={year}
                  onChange={(e) => setYear(parseInt(e.target.value))}
                  className="selection__input"
                >
                  <option value="2025">2025</option>
                </select>
                <select
                  value={month}
                  onChange={(e) => setMonth(parseInt(e.target.value))}
                  className="selection__input"
                >
                  <option value="">Select Month&nbsp;</option>
                  <option value="1">Jan</option>
                  <option value="2">Feb</option>
                  <option value="3">March</option>
                  <option value="4">April</option>
                  <option value="5">May</option>
                  <option value="6">June</option>
                  <option value="7">July</option>
                  <option value="8">August</option>
                  <option value="9">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12">December</option>
                </select>
                <button
                  className="btn btn--green"
                  onClick={() => {
                    fetchData(mill, year, month);
                  }}
                >
                  Show Runtime
                </button>
                <button
                  onClick={(e) => {
                    if (month && year && mill) {
                      const paramsTemp = new URLSearchParams();
                      paramsTemp.append("month", month.toString());
                      paramsTemp.append("year", year.toString());
                      paramsTemp.append("mill", mill.toString());

                      agent.Lora.downloadReportUptime(paramsTemp);
                    }
                    e.preventDefault();
                  }}
                  className="btn btn--green"
                >
                  ToExcel
                </button>
              </div>
              <DataGrid
                data={data || []}
                columns={sensorDataColumn}
                lockable={true}
                selectedIndex={selectedIndex}
                onRowClick={(_, i) => setSelectedIndex(i)}
                currentPage={currentPage}
                totalPages={totalPages}
                totalRecords={totalData}
                pageSize={pageSize}
                onPageChange={(newPage) => {
                  fetchData(mill, year, month);
                  setCurrentPage(newPage);
                }}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1); // reset to page 1
                  fetchData(mill, year, month);
                }}
                loading={isLoading}
              />
            </div>
          </main>
        </div>
        <Footer />
        <div id="popup" className={popupClass}>
          <div className="popup__content">
            <span className="popup__close">&times;</span>
            <div id="curveChart" className="popup__chart"></div>
          </div>
        </div>
      </div>
    </>
  );
}
export default UptimeMonitoring;
