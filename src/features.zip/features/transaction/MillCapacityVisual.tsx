import "../../css/style2.css";
import "../../css/grid.css";
import "../../css/form.css";
import "../../css/style_popup.css";
import { useEffect, useState, useMemo } from "react";
import NavLane from "../../NavLane";
import Footer from "../../Footer";
import Header from "../../Header";

import DataGrid from "../component/DataGrid";
import Plotly from "plotly.js-dist-min";
import { CONFIG } from "../../config/millConfig";
import ProgressBarPlot from "../component/ProgressBarPlot";
import { useStore } from "../../app/store/store";
import { observer } from "mobx-react-lite";

type MillCapacityVisual_ = {
  Mill: string;
  Code: string;
  day1: number;
  day2: number;
  day3: number;
  day4: number;
  day5: number;
  day6: number;
  day7: number;
  day8: number;
  day9: number;
  day10: number;
  day11: number;
  day12: number;
  total: number;
  daily_percentage: number;
  total_hours_year: number;
  active_days_year: number;
  yearly_budget_hours: number;
  yearly_percentage: number;
  monthly_percentage: number;
};

type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  group?: string; // ✅ NEW: for grouping headers
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left";
  width?: number;
  wrap?: boolean;
};

export default observer(function MillCapacityVisual() {
  const [year, setYear] = useState(2025);
  const [month, setMonth] = useState(11);

  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalData, setTotalData] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [pageSize, setPageSize] = useState(50);
  const [popupClass, setPopupclass] = useState("popup");
  const [isLoading, setIsLoading] = useState(true);
  const [UoM, setUoM] = useState("percent");

  const { CapacityStore } = useStore();
  const {
    init,
    dispose,
    timeLeft,
    mills,
    activeMill,
    machineHours,
    setActiveMill,
    data,
    fetchData,
    loading,
  } = CapacityStore;

  // inside MillCapacityVisual()
  const labelByKey = useMemo(() => {
    const series =
      CONFIG[activeMill as keyof typeof CONFIG]?.groups.flatMap(
        (g) => g.series
      ) ?? [];
    return Object.fromEntries(series.map((s) => [s.key, s.label ?? s.key]));
  }, [activeMill]);

  const sensorDataColumnPer: ColumnDefinition<MillCapacityVisual_>[] = [
    {
      header: "#",
      key: "row_index",
      render: (_: MillCapacityVisual_, i: number) =>
        i + 1 + (currentPage - 1) * pageSize,
      align: "left",
      width: 11,
    },
    {
      header: "Sensor Code",
      key: "Code",
      wrap: true,
      width: 150,
      render: (row: MillCapacityVisual_) => labelByKey[row.Code] ?? row.Code,
    },
    { header: "Daily", key: "daily_percentage", width: 75, align: "right" },
    { header: "Monthly", key: "monthly_percentage", width: 75, align: "right" },
    {
      header: "Active Days",
      key: "active_days_year",
      width: 75,
      align: "right",
      group: "Year",
    },
    {
      header: "Percentage",
      key: "yearly_percentage",
      width: 75,
      align: "right",
      group: "Year",
    },
    {
      header: "Yearly Availability",
      key: "yearly_percentage",
      width: 55,
      align: "left",
      render: (row) => <ProgressBarPlot value={row.yearly_percentage} />,
    },
  ];

  useEffect(() => {
    init();
    return () => dispose();
  }, []);

  // Close button and popup logic
  const closeBtn = document.querySelector(".popup__close") as HTMLElement;
  const popup = document.getElementById("popup") as HTMLElement;

  closeBtn?.addEventListener("click", () => {
    setPopupclass("popup");
    Plotly.purge("curveChart");
  });

  window.addEventListener("click", (event) => {
    if (event.target === popup) {
      setPopupclass("popup");
      Plotly.purge("curveChart");
    }
  });

  return (
    <>
      <div className="layout">
        <Header />
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <div className="visual-wrapper">
              <div className="headerGrid">
                <div className="vizTitle">Arus (Ampere)</div>
                <div className="headerCountdown">
                  {activeMill} — {Math.floor(timeLeft / 60)}:
                  {String(timeLeft % 60).padStart(2, "0")}
                </div>
                <div className="millToggleGroup">
                  {mills.map((mill) => {
                    const active = activeMill === mill;
                    return (
                      <button
                        key={mill}
                        type="button"
                        className={`millToggle ${active ? "isActive" : ""}`}
                        onClick={() => setActiveMill(mill)}
                        aria-pressed={active}
                      >
                        {mill}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="card-overview">
                <div className="card-container">
                  <h4>Mill</h4>
                  <h3>Runtime Hours</h3>
                  <b>
                    <h1>
                      {machineHours.availability.get("060081 - CBC")?.today}
                    </h1>
                  </b>
                </div>
                <div className="card-container" id="visual-card-cbc1"></div>
                <div className="card-container">
                  <h4>KCP Stage-1</h4>
                  <h3>Runtime Hours</h3>
                  <b>
                    <h1>{machineHours.availability.get("KCP1")?.today}</h1>
                  </b>
                </div>
                <div className="card-container">
                  <h4>KCP Stage-2</h4>
                  <h3>Runtime Hours</h3>
                  <b>
                    <h1>{machineHours.availability.get("KCP2")?.today}</h1>
                  </b>
                </div>
              </div>
              <DataGrid
                data={data || []}
                columns={sensorDataColumnPer}
                lockable={true}
                selectedIndex={selectedIndex}
                onRowClick={(_, i) => setSelectedIndex(i)}
                currentPage={currentPage}
                totalPages={totalPages}
                totalRecords={totalData}
                pageSize={pageSize}
                onPageChange={(newPage) => {
                  fetchData(activeMill, year, month);
                  setCurrentPage(newPage);
                }}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1); // reset to page 1
                  fetchData(activeMill, year, month);
                }}
                loading={loading}
              />
            </div>
          </main>
        </div>
        <Footer />
        <div id="popup" className={popupClass}>
          <div className="popup__content">
            <span className="popup__close">&times;</span>
            <div id="curveChart" className="popup__chart"></div>
          </div>
        </div>
      </div>
    </>
  );
});
