import "../../css/style2.css";
import "../../css/form.css";
import "../../css/style_popup.css";
import { useEffect, useState } from "react";
import NavLane from "../../NavLane";
import Footer from "../../Footer";
import Header from "../../Header";
import agent from "../../app/api/agent";
import PopupModal from "../component/PopupModal";
import ConfirmationPopup from "../component/ConfirmationPopup";
import DataGrid from "../component/DataGrid";

type InspectionDataType = {
  mill: string;
  day_1: number;
  day_2: number;
  day_3: number;
  day_4: number;
  day_5: number;
  day_6: number;
  day_7: number;
  day_8: number;
  day_9: number;
  day_10: number;
  day_11: number;
  day_12: number;
  day_13: number;
  day_14: number;
  day_15: number;
  day_16: number;
  day_17: number;
  day_18: number;
  day_19: number;
  day_20: number;
  day_21: number;
  day_22: number;
  day_23: number;
  day_24: number;
  day_25: number;
  day_26: number;
  day_27: number;
  day_28: number;
  day_29: number;
  day_30: number;
  day_31: number;
  description: string;
  item: string;
  location: string;
  machine_code: string;
  machinecode: string;
  max_val: string;
  min_val: string;
  percentage: string;
  reading: string;
  series_key: string;
  status: string;
  theitem: string;
  themill: string;
  total_corrective: string;
};

type ListMill_ = {
  Value: string;
  Code: string;
};

function getNow(GetSevenAM: string) {
  const now = new Date();
  if (GetSevenAM == "yes") {
    now.setHours(7, 0, 0, 0); // set to 07:00:00
  }
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  const hh = String(now.getHours()).padStart(2, "0");
  const mi = String(now.getMinutes()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
}

type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  group?: string; // ✅ NEW: for grouping headers
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left";
  width?: number;
  wrap?: boolean;
};

function InspectionDataGrid() {
  const [Mill, SetMill] = useState("");
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [startDate, setStartDate] = useState(getNow("yes"));
  const [endDate, setEndDate] = useState(getNow(""));
  const [data, setData] = useState<InspectionDataType[] | null>(null);

  const [ListMill, SetListMill] = useState<ListMill_[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalData, setTotalData] = useState(0);
  const [pageSize, setPageSize] = useState(50);

  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const [showModal, setShowModal] = useState(false);

  const gridColumn: ColumnDefinition<InspectionDataType>[] = [
    {
      header: "#",
      key: "index",
      render: (_: InspectionDataType, i: number) =>
        i + 1 + (currentPage - 1) * pageSize,
      align: "right" as const,
    },
    { header: "Parameter Machine", key: "series_key" },
    { header: "Satuan", key: "Question" },
    { header: "Min", key: "min_val" },
    { header: "Max", key: "max_val" },
    {
      header: "Last Check",
      key: "DateCreate",
    },
    { header: "1", key: "day_1" },
    { header: "2", key: "day_2" },
    { header: "3", key: "day_3" },
    { header: "4", key: "day_4" },
    { header: "5", key: "day_5" },
    { header: "6", key: "day_6" },
    { header: "7", key: "day_7" },
    { header: "8", key: "day_8" },
    { header: "9", key: "day_9" },
    { header: "10", key: "day_10" },
    { header: "11", key: "day_11" },
    { header: "12", key: "day_12" },
    { header: "13", key: "day_13" },
    { header: "14", key: "day_14" },
    { header: "15", key: "day_15" },
    { header: "16", key: "day_16" },
    { header: "17", key: "day_17" },
    { header: "18", key: "day_18" },
    { header: "19", key: "day_19" },
    { header: "20", key: "day_20" },
    { header: "21", key: "day_21" },
    { header: "22", key: "day_22" },
    { header: "23", key: "day_23" },
    { header: "24", key: "day_24" },
    { header: "25", key: "day_25" },
    { header: "26", key: "day_26" },
    { header: "27", key: "day_27" },
    { header: "28", key: "day_28" },
    { header: "29", key: "day_29" },
    { header: "30", key: "day_30" },
    { header: "31", key: "day_31" },
  ];

  const fetchData = async (
    mill_: string,
    year: string,
    month: string,
    currentPage_: number,
    pageSize_: number
  ) => {
    try {
      year = "2025";
      month = "5";
      await agent.AACM.getInspectionReport(
        mill_,
        year,
        month,
        currentPage_,
        pageSize_
      ).then((response: any) => {
        setData(response); // response.data.rows if using { rows, total }
        setTotalPages(Math.ceil(response.total / pageSize)); // if backend returns total count
        setTotalData(response.total);
      });
    } catch (err) {
      console.error("err : " + err);
    }
  };

  useEffect(() => {
    fetchData(Mill, startDate, endDate, currentPage, pageSize);
  }, [Mill, "", startDate, endDate]);

  useEffect(() => {
    try {
      agent.AACM.getListMill().then((response) => {
        SetListMill(response.data);
      });
    } catch (err) {
      console.error("err : " + err);
    }
  }, []);

  return (
    <>
      <div className="layout">
        <Header />
        {/* Main layout body: nav + content */}
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <div className="sensor-container">
              <div className="controls">
                <select
                  value={Mill}
                  onChange={(e) => {
                    SetMill(e.target.value);
                    console.log(e.target.value);
                  }}
                  className="selection__input"
                >
                  <option value="">Pilihan Mill</option>
                  {Array.isArray(ListMill) ? (
                    ListMill.map((row) => (
                      <option value={row.Value + ""}>{row.Code}</option>
                    ))
                  ) : (
                    <></>
                  )}
                </select>
                <input
                  type="datetime-local"
                  className="selection__input"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
                <input
                  type="datetime-local"
                  className="selection__input"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
                <div style={{ marginLeft: ".25rem" }}>
                  <button
                    onClick={() => {
                      fetchData(Mill, startDate, endDate, 0, pageSize);
                    }}
                  >
                    Refresh
                  </button>
                </div>
              </div>
              <DataGrid
                data={data || []}
                columns={gridColumn}
                selectedIndex={selectedIndex}
                onRowClick={(_, i) => setSelectedIndex(i)}
                currentPage={currentPage}
                totalPages={0}
                totalRecords={totalData}
                pageSize={pageSize}
                onPageChange={(newPage) => {
                  fetchData(Mill, startDate, endDate, newPage, pageSize);
                  setCurrentPage(newPage);
                }}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1); // reset to page 1
                  fetchData(Mill, startDate, endDate, 1, newSize);
                }}
              />
            </div>
          </main>
        </div>
        <Footer />
        <PopupModal
          title={"Confirmation"}
          show={showModal}
          onClose={() => setShowModal(false)}
        >
          <></>
        </PopupModal>
        <ConfirmationPopup
          show={showConfirmation}
          testIdSubmitButton="InspectionConfirmationPopup"
          onCancel={() => setShowConfirmation(false)}
          onConfirm={() => {
            return false;
          }}
        />
      </div>
    </>
  );
}
export default InspectionDataGrid;
