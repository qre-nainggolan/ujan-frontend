import "../../css/style2.css";
import "../../css/grid.css";
import "../../css/form.css";
import "../../css/style_popup.css";
import { useEffect, useState, useMemo } from "react";
import NavLane from "../../NavLane";
import Footer from "../../Footer";
import Header from "../../Header";
import agent from "../../app/api/agent";
import DataGrid from "../component/DataGrid";
import Plotly from "plotly.js-dist-min";
import { CONFIG } from "../../config/millConfig";
import Calendar from "../component/Calendar";

type Sensor = {
  Mill: string;
  Code: string;
  Parameter: string;
  Value: number;
  SensorDate: string;
  DateCreate: string;
};

type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  group?: string; // ✅ NEW: for grouping headers
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left";
  width?: number;
  wrap?: boolean;
};

function getNow() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  const hh = String(now.getHours()).padStart(2, "0");
  const mi = String(now.getMinutes()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
}

function SensorDataGrid() {
  const [mill, setMill] = useState("PAN");
  const [machineID, setMachineID] = useState("");
  const [machineLabel, setMachineLabel] = useState("");
  const [startDate, setStartDate] = useState(getNow());
  const [endDate, setEndDate] = useState(getNow());
  const [data, setData] = useState<Sensor[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalData, setTotalData] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [pageSize, setPageSize] = useState(50);
  const [popupClass, setPopupclass] = useState("popup");

  // inside SensorDataGrid()
  const labelByKey = useMemo(() => {
    const series =
      CONFIG[mill as keyof typeof CONFIG]?.groups.flatMap((g) => g.series) ??
      [];
    return Object.fromEntries(series.map((s) => [s.key, s.label ?? s.key]));
  }, [mill]);

  const sensorDataColumn: ColumnDefinition<Sensor>[] = [
    {
      header: "#",
      key: "row_index",
      render: (_: Sensor, i: number) => i + 1 + (currentPage - 1) * pageSize,
      align: "right",
      width: 20,
    },
    {
      header: "Mill",
      key: "Mill",
      width: 150,
    },
    {
      header: "Sensor Code",
      key: "Code",
      wrap: true,
      width: 200,
      render: (row: Sensor) => labelByKey[row.Code] ?? row.Code,
    },
    {
      header: "Parameter",
      key: "Parameter",
      width: 150,
    },
    {
      header: "Value",
      key: "Value",
      width: 250,
    },
    {
      header: "Sensor Date",
      key: "SensorDate",
      width: 140,
      group: "Date Time",
      render: (row: Sensor) =>
        new Date(row.SensorDate).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "UTC",
        }),
    },
    {
      header: "Gateway Date",
      key: "DateCreate",
      group: "Date Time",
      width: 140,
      render: (row: Sensor) =>
        new Date(row.DateCreate).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "UTC",
        }),
    },
  ];

  function formatDateForBackend(dateStr: string) {
    const date = new Date(dateStr);
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    const hh = String(date.getHours()).padStart(2, "0");
    const ii = String(date.getMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${ii}`;
  }

  const fetchData = async (
    machineId_: string,
    mill_: string,
    startDate_: string,
    endDate_: string,
    currentPage_: number,
    pageSize_: number
  ) => {
    try {
      await agent.Lora.getPaginatedSensorData(
        machineId_,
        mill_,
        formatDateForBackend(startDate_),
        formatDateForBackend(endDate_),
        currentPage_,
        pageSize_
      ).then((response) => {
        setData(response.data); // response.data.rows if using { rows, total }
        setTotalPages(Math.ceil(response.total / pageSize)); // if backend returns total count
        setTotalData(response.total);
      });
    } catch (err) {
      console.error("err : " + err);
    }
  };

  useEffect(() => {
    fetchData(machineID, mill, startDate, endDate, currentPage, pageSize);
  }, [mill, machineID, startDate, endDate]);

  // Close button and popup logic
  const closeBtn = document.querySelector(".popup__close") as HTMLElement;
  const popup = document.getElementById("popup") as HTMLElement;

  closeBtn?.addEventListener("click", () => {
    setPopupclass("popup");
    Plotly.purge("curveChart");
  });

  window.addEventListener("click", (event) => {
    if (event.target === popup) {
      setPopupclass("popup");
      Plotly.purge("curveChart");
    }
  });

  function formatDate(date_: Date | null) {
    const yyyy = date_!.getFullYear();
    const mm = String(date_!.getMonth() + 1).padStart(2, "0");
    const dd = String(date_!.getDate()).padStart(2, "0");
    const hh = String(date_!.getHours()).padStart(2, "0");
    const mi = String(date_!.getMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  }

  function movingAverage(arr: number[], windowSize = 20) {
    const smoothed = [];
    for (let i = 0; i < arr.length; i++) {
      const start = Math.max(0, i - Math.floor(windowSize / 2));
      const end = Math.min(arr.length, i + Math.ceil(windowSize / 2));
      const window = arr.slice(start, end);
      const avg = window.reduce((sum, val) => sum + val, 0) / window.length;
      smoothed.push(avg);
    }
    return smoothed;
  }

  function insertNullsForPlotly(
    data: any,
    timeKey: any,
    valueKey: any,
    gapMinutes = 10
  ) {
    const result = [];
    const gapThresholdMs = gapMinutes * 60 * 1000;

    for (let i = 0; i < data.results.length; i++) {
      const current = data.results[i];
      result.push(current);

      const next = data.results[i + 1];
      if (next) {
        const t1: any = new Date(current[timeKey]);
        const t2: any = new Date(next[timeKey]);

        if (t2 - t1 > gapThresholdMs) {
          result.push({
            ...next,
            [valueKey]: null,
          });
        }
      }
    }

    return result;
  }

  return (
    <>
      <div className="layout">
        <Header />
        {/* Main layout body: nav + content */}
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <div className="sensor-container">
              <div className="controls">
                <select
                  value={mill}
                  onChange={(e) => setMill(e.target.value)}
                  className="selection__input"
                >
                  <option value="">Select Mill</option>
                  <option value="PAN">PAN</option>
                  <option value="PSG">PSG</option>
                </select>
                <select
                  value={machineID}
                  onChange={(e) => {
                    const selectedValue = e.target.value;
                    const selectedLabel =
                      e.target.options[e.target.selectedIndex].getAttribute(
                        "data-label"
                      ) ?? "";
                    setMachineID(selectedValue);
                    setMachineLabel(selectedLabel);
                  }}
                >
                  <option value="">Select Machine ID</option>
                  {mill &&
                    CONFIG[mill as keyof typeof CONFIG]?.groups.flatMap(
                      (group) =>
                        group.series.map((s) => (
                          <option key={s.key} value={s.key}>
                            {s.label || s.key}
                          </option>
                        ))
                    )}
                </select>
                <Calendar
                  name="StartDate"
                  id="StartDate"
                  value={startDate}
                  selected={startDate ? new Date(startDate) : new Date()}
                  onChange={(date: Date | null) => {
                    setStartDate(formatDate(date));
                  }}
                  dateFormat="yyyy-MM-dd"
                  className="selection__input w-full"
                  wrapperClassName="w-full"
                />
                <Calendar
                  name="EndDate"
                  id="EndDate"
                  value={endDate}
                  selected={startDate ? new Date(endDate) : new Date()}
                  onChange={(date: Date | null) => {
                    setEndDate(formatDate(date));
                  }}
                  dateFormat="yyyy-MM-dd"
                  className="selection__input w-full"
                  wrapperClassName="w-full"
                />
                <button
                  className="btn btn--green"
                  onClick={() => {
                    fetchData(machineID, mill, startDate, endDate, 0, pageSize);
                  }}
                >
                  Show Data
                </button>
                <button
                  className="btn btn--green"
                  onClick={() => {
                    // fetchData(machineID, mill, startDate, endDate, 0, pageSize);
                    setPopupclass("popup-show");

                    agent.Lora.getCurrentGraphFromGrid(
                      mill,
                      formatDateForBackend(startDate),
                      formatDateForBackend(endDate),
                      machineID
                    )
                      .then((data) => {
                        const processed = insertNullsForPlotly(
                          data,
                          "M",
                          "R",
                          5
                        );

                        const x = processed.map((d: any) => d.M);
                        const yRaw = processed.map((d: any) => d.R);
                        const ySmooth = movingAverage(yRaw, 10);

                        const rawTrace = {
                          x,
                          y: yRaw,
                          mode: "lines+marker",
                          name: "Raw Data",
                          line: { color: "#0067c1", width: 2 },
                          type: "scatter",
                          connectgaps: false,
                        };

                        const smoothTrace = {
                          x,
                          y: ySmooth,
                          mode: "lines",
                          name: "Smoothed Curve",
                          line: {
                            color: "#28016c",
                            width: 2.5,
                          },
                          type: "scatter",
                          connectgaps: false,
                        };

                        Plotly.newPlot(
                          "curveChart",
                          [rawTrace, smoothTrace],
                          {
                            title: {
                              text: "" + labelByKey[machineID]!,
                              font: {
                                size: 32,
                                color: "#0067c1",
                              },
                            },
                            shapes: [
                              {
                                x0: 0,
                                x1: 1,
                                y0: parseFloat(data.critical),
                                y1: parseFloat(data.critical),
                                type: "line",
                                xref: "paper",
                                yref: "y",
                                line: {
                                  color: "red",
                                  width: 0.75,
                                  dash: "dash",
                                },
                              },
                              {
                                x0: 0,
                                x1: 1,
                                y0: parseFloat(data.warning),
                                y1: parseFloat(data.warning),
                                type: "line",
                                xref: "paper",
                                yref: "y",
                                line: {
                                  color: "green",
                                  width: 0.75,
                                  dash: "dash",
                                },
                              },
                              {
                                x0: 0,
                                x1: 1,
                                y0: parseFloat(data.fullLoad),
                                y1: parseFloat(data.fullLoad),
                                type: "line",
                                xref: "paper",
                                yref: "y",
                                line: {
                                  color: "green",
                                  width: 0.75,
                                  dash: "dash",
                                },
                              },
                              {
                                x0: 0,
                                x1: 1,
                                y0: parseFloat(data.power),
                                y1: parseFloat(data.power),
                                type: "line",
                                xref: "paper",
                                yref: "y",
                                line: {
                                  color: "blue",
                                  width: 0.75,
                                  dash: "dash",
                                },
                              },
                            ],
                            annotations: [
                              {
                                xref: "paper",
                                x: 1,
                                y: parseFloat(data.critical),
                                xanchor: "left",
                                yanchor: "middle",
                                text: "Critical",
                                showarrow: false,
                                font: { color: "red" },
                              },
                              {
                                xref: "paper",
                                x: 1,
                                y: parseFloat(data.warning),
                                xanchor: "left",
                                yanchor: "middle",
                                text: "Warning",
                                showarrow: false,
                                font: { color: "green" },
                              },
                              {
                                xref: "paper",
                                x: 1,
                                y: parseFloat(data.fullLoad),
                                xanchor: "left",
                                yanchor: "middle",
                                text: "Full Load",
                                showarrow: false,
                                font: { color: "green" },
                              },
                              {
                                xref: "paper",
                                x: 1,
                                y: parseFloat(data.power),
                                xanchor: "left",
                                yanchor: "middle",
                                text: "Power",
                                showarrow: false,
                                font: { color: "blue" },
                              },
                              {
                                text: "Last Update at " + data.lastUpdate,
                                x: 1,
                                y: 1,
                                xref: "paper",
                                yref: "paper",
                                showarrow: false,
                                font: {
                                  size: 12,
                                  color: "#28016c",
                                },
                                xanchor: "right",
                              },
                              {
                                x: 1,
                                y: 0.92,
                                showarrow: false,
                                align: "left",
                                xanchor: "left",
                                borderwidth: 1,
                                bordercolor: "gray",
                                bgcolor: "#f0f0f0",
                                borderpad: 4,
                                xref: "paper",
                                yref: "y",
                                text:
                                  "<b>Note: <br>Total Runtime : " +
                                  parseFloat(data.totalRuntime).toFixed(2) +
                                  " hours</b>",
                                font: {
                                  color: "green",
                                  size: 10,
                                },
                              },
                            ],
                            xaxis: {
                              title: "Time",
                              automargin: true,
                              color: "#000",
                            },
                            yaxis: { title: "Value", color: "#000" },
                            paper_bgcolor: "#efe7e7",
                            plot_bgcolor: "#efe7e7",
                            font: {
                              family: "Poppins, sans-serif",
                              color: "#28016c",
                            },
                          },
                          { responsive: true }
                        );
                      })
                      .then(() => {
                        setTimeout(() => {
                          Plotly.Plots.resize(
                            document.getElementById("curveChart")
                          );
                        }, 300);
                      })
                      .catch((err) => {
                        console.error("Failed to load data:", err);
                      });
                  }}
                >
                  Show Chart
                </button>
              </div>
              <DataGrid
                data={data || []}
                columns={sensorDataColumn}
                lockable={true}
                selectedIndex={selectedIndex}
                onRowClick={(_, i) => setSelectedIndex(i)}
                currentPage={currentPage}
                totalPages={totalPages}
                totalRecords={totalData}
                pageSize={pageSize}
                onPageChange={(newPage) => {
                  fetchData(
                    machineID,
                    mill,
                    startDate,
                    endDate,
                    currentPage + 1,
                    pageSize
                  );
                  setCurrentPage(newPage);
                }}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1); // reset to page 1
                  fetchData(machineID, mill, startDate, endDate, 1, pageSize);
                }}
              />
            </div>
          </main>
        </div>
        <Footer />
        <div id="popup" className={popupClass}>
          <div className="popup__content">
            <span className="popup__close">&times;</span>
            <div id="curveChart" className="popup__chart"></div>
          </div>
        </div>
      </div>
    </>
  );
}
export default SensorDataGrid;
