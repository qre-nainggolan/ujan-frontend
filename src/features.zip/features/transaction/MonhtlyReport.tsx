import "../../css/style2.css";
import "../../css/grid.css";
import "../../css/form.css";
import "../../css/style_popup.css";
import { useEffect, useState, useMemo } from "react";
import NavLane from "../../NavLane";
import Footer from "../../Footer";
import Header from "../../Header";
import agent from "../../app/api/agent";
import DataGrid from "../component/DataGrid";
import Plotly from "plotly.js-dist-min";
import { CONFIG } from "../../config/millConfig";

type MonthlyReport_ = {
  Mill: string;
  Code: string;
  1: number;
  2: number;
  3: number;
  4: number;
  5: number;
  6: number;
  7: number;
  8: number;
  9: number;
  10: number;
  11: number;
  12: number;
  total: number;
};

type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  group?: string; // ✅ NEW: for grouping headers
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left";
  width?: number;
  wrap?: boolean;
};

function MonthlyReport() {
  const [mill, setMill] = useState("PSG");
  const [year, setYear] = useState(2025);
  const [month, setMonth] = useState(11);
  const [data, setData] = useState<MonthlyReport_[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalData, setTotalData] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [pageSize, setPageSize] = useState(50);
  const [popupClass, setPopupclass] = useState("popup");
  const [isLoading, setIsLoading] = useState(true);

  // inside MonthlyReport()
  const labelByKey = useMemo(() => {
    const series =
      CONFIG[mill as keyof typeof CONFIG]?.groups.flatMap((g) => g.series) ??
      [];
    return Object.fromEntries(series.map((s) => [s.key, s.label ?? s.key]));
  }, [mill]);

  const sensorDataColumn: ColumnDefinition<MonthlyReport_>[] = [
    {
      header: "#",
      key: "row_index",
      render: (_: MonthlyReport_, i: number) =>
        i + 1 + (currentPage - 1) * pageSize,
      align: "right",
      width: 10,
    },
    {
      header: "Sensor Code",
      key: "Code",
      wrap: true,
      width: 150,
      render: (row: MonthlyReport_) => labelByKey[row.Code] ?? row.Code,
    },
    { header: "Jan", key: "1", width: 60, align: "right" },
    { header: "Feb", key: "2", width: 60, align: "right" },
    { header: "Mar", key: "3", width: 60, align: "right" },
    { header: "Apr", key: "4", width: 60, align: "right" },
    { header: "May", key: "5", width: 60, align: "right" },
    { header: "Jun", key: "6", width: 60, align: "right" },
    { header: "Jul", key: "7", width: 60, align: "right" },
    { header: "Aug", key: "8", width: 60, align: "right" },
    { header: "Sep", key: "9", width: 60, align: "right" },
    { header: "Oct", key: "10", width: 60, align: "right" },
    { header: "Nov", key: "11", width: 60, align: "right" },
    { header: "Dec", key: "12", width: 60, align: "right" },
    { header: "Total", key: "total", width: 60, align: "right" },
  ];

  const fetchData = async (mill_: string, year_: number, month_: number) => {
    setIsLoading(true);
    try {
      await agent.Lora.getMonthlyReport(mill_, year_).then((response) => {
        setData(response.data); // response.data.rows if using { rows, total }
      });
    } catch (err) {
      console.error("err : " + err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData(mill, year, month);
  }, [mill, year, month]);

  // Close button and popup logic
  const closeBtn = document.querySelector(".popup__close") as HTMLElement;
  const popup = document.getElementById("popup") as HTMLElement;

  closeBtn?.addEventListener("click", () => {
    setPopupclass("popup");
    Plotly.purge("curveChart");
  });

  window.addEventListener("click", (event) => {
    if (event.target === popup) {
      setPopupclass("popup");
      Plotly.purge("curveChart");
    }
  });

  return (
    <>
      <div className="layout">
        <Header />
        {/* Main layout body: nav + content */}
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <div className="sensor-container">
              <div className="controls">
                <select
                  value={mill}
                  onChange={(e) => setMill(e.target.value)}
                  className="selection__input"
                >
                  <option value="">Select Mill</option>
                  <option value="PAN">PAN</option>
                  <option value="PSG">PSG</option>
                </select>
                <select
                  value={year}
                  onChange={(e) => setYear(parseInt(e.target.value))}
                  className="selection__input"
                >
                  <option value="2025">2025</option>
                </select>
                <button
                  className="btn btn--green"
                  onClick={() => {
                    fetchData(mill, year, month);
                  }}
                >
                  Show Monthly Runtime
                </button>
                <button
                  onClick={(e) => {
                    if (month && year && mill) {
                      const paramsTemp = new URLSearchParams();
                      paramsTemp.append("month", month.toString());
                      paramsTemp.append("year", year.toString());
                      paramsTemp.append("mill", mill.toString());

                      agent.Lora.downloadRuntimeMonthly(paramsTemp);
                    }
                    e.preventDefault();
                  }}
                  className="btn btn--green"
                >
                  ToExcel
                </button>
              </div>
              <DataGrid
                data={data || []}
                columns={sensorDataColumn}
                lockable={true}
                selectedIndex={selectedIndex}
                onRowClick={(_, i) => setSelectedIndex(i)}
                currentPage={currentPage}
                totalPages={totalPages}
                totalRecords={totalData}
                pageSize={pageSize}
                onPageChange={(newPage) => {
                  fetchData(mill, year, month);
                  setCurrentPage(newPage);
                }}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1); // reset to page 1
                  fetchData(mill, year, month);
                }}
                loading={isLoading}
              />
            </div>
          </main>
        </div>
        <Footer />
        <div id="popup" className={popupClass}>
          <div className="popup__content">
            <span className="popup__close">&times;</span>
            <div id="curveChart" className="popup__chart"></div>
          </div>
        </div>
      </div>
    </>
  );
}
export default MonthlyReport;
