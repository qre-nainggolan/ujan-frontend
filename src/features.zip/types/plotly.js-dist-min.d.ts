declare module "plotly.js-dist-min" {
  const Plotly: any;
  export default Plotly;
}
