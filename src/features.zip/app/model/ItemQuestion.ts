export interface ItemQuestion {
  id: number;
  text: string;
  done: boolean;
  choices: string[];
}
