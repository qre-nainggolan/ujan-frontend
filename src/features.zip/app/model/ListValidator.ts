export interface ListValidator {
  userID: string;
  nama_User: string;
}
