export interface PrintModel {
  status: string;
  dataPrint: string;
}
