export interface ListUserScore {
  started_at: string;
  total: string;
  correct: string;
}
