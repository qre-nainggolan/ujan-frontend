export interface ListAnswer {
  questionId: number;
  answer: string | null;
}
