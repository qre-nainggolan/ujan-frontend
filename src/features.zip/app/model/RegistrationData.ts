export interface RegistrationData {
  username: string;
  email: string;
  password: string;
  appliedInstance?: string;
  emailConfirmed: string;
  dateCreate: string;
  userStatus: string;
}
