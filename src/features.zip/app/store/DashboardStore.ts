// src/app/store/DashboardStore.ts
import { makeAutoObservable, runInAction } from "mobx";
import Plotly from "plotly.js-dist-min";
import agent from "../api/agent";

type ChartType = "gauge10" | "gauge100" | "bar";
type Series = { key: string; label?: string; type?: ChartType };
type Group = { title: string; series: Series[] };
type MillConfig = { groups: Group[] };

const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

/** CONFIG: define groups per mill */
export const CONFIG: Record<"PAN" | "PSG", MillConfig> = {
  PAN: {
    groups: [
      {
        title: "Power",
        series: [{ key: "PAN_Fuel_Dist", label: "Fuel Dist" }].map((k) => ({
          key: k.key,
          label: k.label,
          type: "gauge100",
        })),
      },
      {
        title: "KCP",
        series: [
          { key: "PAN_KCP_1_1", label: "First KCP 1" },
          { key: "PAN_KCP_1_2", label: "First KCP 2" },
          { key: "PAN_KCP_1_3", label: "First KCP 3" },
        ].map((k) => ({ key: k.key, label: k.label, type: "gauge100" })),
      },
    ],
  },
  PSG: {
    groups: [
      {
        title: "Power",
        series: [
          { key: "07010", label: "Induced Draft Fan 1" },
          { key: "07011", label: "Induced Draft Fan 2" },
          { key: "07013", label: "Forced Draft Fan 1" },
          { key: "07014", label: "Forced Draft Fan 2" },
          { key: "07016", label: "Secondary Draft Fan 1" },
          { key: "07017", label: "Secondary Draft Fan 2" },
        ].map((k) => ({ key: k.key, label: k.label, type: "gauge100" })),
      },
      {
        title: "Thresher",
        series: [
          { key: "03011", label: "Thresher 1" },
          { key: "03012", label: "Thresher 2" },
          { key: "03013", label: "Thresher 3" },
          { key: "03047", label: "Empty Bunch Press 1" },
          { key: "03048", label: "Empty Bunch Press 2" },
          { key: "03049", label: "Empty Bunch Press 3" },
          { key: "03050", label: "Empty Bunch Press 4" },
        ].map((k) => ({ key: k.key, label: k.label, type: "gauge100" })),
      },
      {
        title: "Digester & Press",
        series: [
          { key: "04001", label: "Digester 1" },
          { key: "04002", label: "Digester 2" },
          { key: "04003", label: "Digester 3" },
          { key: "04004", label: "Digester 4" },
          { key: "04005", label: "Digester 5" },
          { key: "04007", label: "Screw Pres 1" },
          { key: "04008", label: "Screw Pres 2" },
          { key: "04009", label: "Screw Pres 3" },
          { key: "04010", label: "Screw Pres 4" },
          { key: "04011", label: "Screw Pres 5" },
        ].map((k) => ({ key: k.key, label: k.label, type: "gauge100" })),
      },
      {
        title: "Clarification",
        series: [
          { key: "05001", label: "Sludge Sep. 1" },
          { key: "05002", label: "Sludge Sep. 2" },
          { key: "05003", label: "Sludge Sep. 3" },
          { key: "05004", label: "Sludge Sep. 4" },
          { key: "05005", label: "Sludge Sep. 5" },
          { key: "05070", label: "Sludge Sep. 6" },
          { key: "05071", label: "Sludge Sep. 7" },
          { key: "05072", label: "Sludge Sep. 8" },
        ].map((k) => ({ key: k.key, label: k.label, type: "gauge100" })),
      },
      {
        title: "Kernel",
        series: [
          { key: "06007", label: "CBC 1" },
          { key: "06008", label: "CBC 2" },
          { key: "06009", label: "Fibre Cyc. 1" },
          { key: "06013", label: "Nut Elevator" },
          { key: "06001", label: "Ripple Mill 1" },
          { key: "06002", label: "Ripple Mill 2" },
          { key: "06003", label: "Ripple Mill 3" },
          { key: "06018", label: "Cracked Mix Con.1" },
          { key: "06022", label: "LTDS 1 Cyc. 1" },
          { key: "06023", label: "LTDS 1 Cyc. 2" },
        ].map((k) => ({ key: k.key, label: k.label, type: "gauge100" })),
      },
      {
        title: "KCP",
        series: [
          { key: "22004", label: "First Press 1" },
          { key: "22005", label: "First Press 2" },
          { key: "22006", label: "First Press 3" },
          { key: "22007", label: "First Press 4" },
          { key: "22008", label: "First Press 5" },
          { key: "22025", label: "Second Press 1" },
          { key: "22026", label: "Second Press 2" },
          { key: "22027", label: "Second Press 3" },
          { key: "22028", label: "Second Press 4" },
          { key: "22029", label: "Second Press 5" },
        ].map((k) => ({ key: k.key, label: k.label, type: "gauge100" })),
      },
    ],
  },
};

export default class DashboardStore {
  seriesStatus = new Map<
    string,
    "normal" | "out-power" | "out-of-range" | "critical"
  >();
  // Define your boundary limits

  // UI
  popupClass = "popup";
  primaryColor = "#0067c1";
  mills = ["PAN", "PSG"] as const;
  activeMill: (typeof this.mills)[number] = "PSG";
  timeLeft = 60;

  private timerId: any = null;

  // machineHours: { availability: any[]; downtime: any[] } = {
  //   availability: [],
  //   downtime: [],
  // };

  machineHours = {
    availability: new Map<string, { today: number; yesterday: number }>(),
    downtime: new Map<
      string,
      {
        yesterday_run: boolean;
        yesterday_breakdown: boolean;
        today_run: boolean;
        today_breakdown: boolean;
      }
    >(),
  };

  // machineHours: Map<string, number> = new Map();
  loadingHours = false;

  constructor() {
    makeAutoObservable(this, {}, { autoBind: true });
  }

  get config(): MillConfig {
    return CONFIG[this.activeMill];
  }

  setActiveMill(mill: (typeof this.mills)[number]) {
    this.activeMill = mill;
    this.timeLeft = 60; // reset countdown to one minute
    this.updateCharts();
  }

  openPopup() {
    this.popupClass = "popup-show";
  }

  closePopup() {
    this.popupClass = "popup";
    try {
      Plotly.purge("curveChart");
    } catch {}
  }

  init() {
    this.updateCharts();
    this.startAutoRefresh();
  }

  dispose() {
    this.stopAutoRefresh();
    try {
      Plotly.purge("curveChart");
    } catch {}
  }

  private startAutoRefresh() {
    if (this.timerId) return;
    this.timerId = setInterval(() => {
      runInAction(() => {
        if (this.timeLeft <= 1) {
          this.timeLeft = 60;
          this.updateCharts();
        } else {
          this.timeLeft -= 1;
        }
      });
    }, 1000);
  }

  private stopAutoRefresh() {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  async fetchMachineHours(mill: string) {
    this.loadingHours = true;
    try {
      const [resAvail, resDown] = await Promise.all([
        agent.Lora.getMachineHour(mill), // existing availability endpoint
        agent.Lora.getMachineDowntime(mill), // new downtime endpoint
      ]);

      // Expect response like your latest JSON
      const { availability = [] } = resAvail;
      const { downtime = [] } = resDown;

      runInAction(() => {
        this.machineHours.availability.clear();
        this.machineHours.downtime.clear();

        availability.forEach(
          (d: { name: string; today: number; yesterday: number }) => {
            this.machineHours.availability.set(d.name, {
              today: d.today,
              yesterday: d.yesterday,
            });
          }
        );

        downtime.forEach(
          (d: {
            name: string;
            today_run: boolean;
            today_breakdown: boolean;
            yesterday_run: boolean;
            yesterday_breakdown: boolean;
          }) => {
            this.machineHours.downtime.set(d.name, {
              today_run: d.today_run,
              today_breakdown: d.today_breakdown,
              yesterday_run: d.yesterday_run,
              yesterday_breakdown: d.yesterday_breakdown,
            });
          }
        );
      });
    } catch (err) {
      console.error("Error fetching machine hours:", err);
    } finally {
      runInAction(() => {
        this.loadingHours = false;
      });
    }
  }

  /** Draw all charts for current mill */
  async updateCharts() {
    // Iterate groups & series
    this.fetchMachineHours(this.activeMill);

    for (const group of this.config.groups) {
      for (const s of group.series) {
        const key = s.key;
        const domId = slug(key); // DOM-safe id

        await this.drawGaugeAnimated(domId, key, -1, {});
      }
    }
  }

  private async drawGaugeAnimated(
    domId: string,
    keyForApi: string,
    targetValue: number,
    obj: any
  ) {
    let latestDate: string | null = null;
    let latestValue: string | null = null;
    let res: any | null = null;

    // Always attempt to get data if targetValue is missing or invalid
    if (targetValue === -1 || isNaN(targetValue)) {
      try {
        res = await agent.Lora.getLatestValue(keyForApi, this.activeMill);
        targetValue = parseFloat(
          (res.validValue || res.validValue !== "") ?? "0"
        );
        latestDate = res.latestDate || null;
        latestValue = res.latestValue || null;
      } catch (err) {
        console.error("Error fetching latest value:", err);
      }
    }

    // Fallbacks if data is still missing
    latestDate = latestDate || null;
    latestValue = latestValue ?? "N/A";

    const el = document.getElementById(domId);
    const elLatestDate = document.getElementById(`latestDate${domId}`);

    // If DOM not ready yet, retry after a short delay
    if (!el || !elLatestDate) {
      setTimeout(
        () => this.drawGaugeAnimated(domId, keyForApi, targetValue, obj),
        200
      );
      return;
    }

    this.seriesStatus.set(
      keyForApi,
      targetValue > parseFloat(res.warning)
        ? "critical"
        : targetValue > parseFloat(res.fullLoad) ||
          targetValue < parseFloat(res.minimum)
        ? "out-of-range"
        : targetValue === -1 ||
          latestValue === "" ||
          latestValue === "-" ||
          latestValue === "N/A" ||
          isNaN(targetValue)
        ? "out-power"
        : "normal"
    );

    // Safely render the date
    let formattedDate: string;
    if (latestDate) {
      try {
        formattedDate = new Date(latestDate).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "UTC",
        });
      } catch {
        formattedDate = "Invalid Date";
      }
    } else {
      formattedDate = "No Data";
    }

    elLatestDate.innerHTML = `${formattedDate} - ${latestValue}`;

    // Draw the gauge if not already present
    if (!(el as any).data) {
      const data = [
        {
          type: "indicator",
          mode: "gauge+number",
          value: targetValue,
          gauge: {
            axis: {
              range: [res.minimum, res.critical],
              tickwidth: 1,
              tickcolor: "darkgray",
            },
            bar: { color: "green" },
            steps: [
              { range: [res.minimum, res.power], color: "#f4f4f4" },
              { range: [res.power, res.fullLoad], color: "#A9D76E" },
              { range: [res.fullLoad, res.warning], color: "#F5F5" },
            ],
          },
        },
      ];

      const layout = {
        margin: { t: 5, r: 30, l: 25, b: 5 },
        paper_bgcolor: "#f5f5f5",
        font: { color: "black", family: "Poppins" },
      };

      Plotly.newPlot(el as any, data, layout, { displayModeBar: false });
    }

    const currentValue = ((el as any).data?.[0]?.value ?? 0) as number;
    this.animateGauge(el, currentValue, targetValue, 600, 20);

    this.togglePanelIcon(
      el,
      targetValue > parseFloat(res.warning)
        ? "critical"
        : targetValue > parseFloat(res.fullLoad) ||
          targetValue < parseFloat(res.minimum)
        ? "alert"
        : targetValue === -1 ||
          latestValue === "" ||
          latestValue === "-" ||
          latestValue === "N/A" ||
          isNaN(targetValue)
        ? "out-power"
        : "normal"
    );
  }

  private insertNullsForPlotly(
    data: any,
    timeKey: any,
    valueKey: any,
    gapMinutes = 10
  ) {
    const result = [];
    const gapThresholdMs = gapMinutes * 60 * 1000;

    for (let i = 0; i < data.results.length; i++) {
      const current = data.results[i];
      result.push(current);

      const next = data.results[i + 1];
      if (next) {
        const t1: any = new Date(current[timeKey]);
        const t2: any = new Date(next[timeKey]);

        if (t2 - t1 > gapThresholdMs) {
          // Insert null value to break the line
          result.push({
            ...next,
            [valueKey]: null,
          });
        }
      }
    }

    return result;
  }

  private animateGauge(
    el: HTMLElement,
    from: number,
    to: number,
    duration: number,
    steps: number
  ) {
    const interval = duration / steps;
    let frame = 0;
    const stepFn = () => {
      frame++;
      const progress = frame / steps;
      const value = from + (to - from) * progress;
      Plotly.restyle(el as any, { value }, [0]);
      if (frame < steps) setTimeout(stepFn, interval);
    };
    stepFn();
  }

  private togglePanelIcon(el: HTMLElement, isAlert: string) {
    const panel = el.closest(".panel__preview-content");
    if (!panel) return;
    const icon = panel.querySelector(".panel__icon");

    if (!icon) return;

    if (isAlert === "alert") {
      icon.classList.add("panel__icon--alert");
      icon.classList.remove("panel__icon--out-power");
      icon.classList.remove("panel__icon--critical");
    } else if (isAlert === "critical") {
      icon.classList.add("panel__icon--critical");
      icon.classList.remove("panel__icon--out-power");
      icon.classList.remove("panel__icon--alert");
    } else if (isAlert === "out-power") {
      icon.classList.add("panel__icon--out-power");
      icon.classList.remove("panel__icon--alert");
      icon.classList.remove("panel__icon--critical");
    } else {
      icon.classList.remove("panel__icon--alert");
      icon.classList.remove("panel__icon--out-power");
      icon.classList.remove("panel__icon--critical");
    }
  }

  /** Curve popup (preview) */
  async plotPreviewCurveForKey(key: string, machineName: string) {
    const data = await agent.Lora.getCurrentGraph(
      this.activeMill,
      "2025-06-01",
      "2025-06-30",
      key
    );

    const processed = this.insertNullsForPlotly(data, "M", "R", 2);

    const x = processed.map((d: any) => d.M);
    const yRaw = processed.map((d: any) => d.R);
    const ySmooth = this.movingAverage(yRaw, 10);

    const totalHMToday = data.results[0].HMT;
    const totalHMNotToday = data.results[0].HMT;
    Plotly.newPlot(
      "curveChart",
      [
        {
          x,
          y: yRaw,
          mode: "lines",
          name: "Raw Data",
          line: { color: this.primaryColor, width: 2 },
          type: "scatter",
          connectgaps: false,
        },
        {
          x,
          y: ySmooth,
          mode: "lines",
          name: "Smoothed Curve",
          line: { shape: "spline", color: "#28016c", width: 2.5 },
          type: "scatter",
        },
      ],
      {
        title: {
          text: machineName,
          font: { size: 32, color: this.primaryColor },
        },
        shapes: [
          {
            x0: 0,
            x1: 1,
            y0: parseFloat(data.critical),
            y1: parseFloat(data.critical),
            type: "line",
            xref: "paper",
            yref: "y",
            line: {
              color: "red",
              width: 0.75,
              dash: "dash",
            },
          },
          {
            x0: 0,
            x1: 1,
            y0: parseFloat(data.warning),
            y1: parseFloat(data.warning),
            type: "line",
            xref: "paper",
            yref: "y",
            line: {
              color: "green",
              width: 0.75,
              dash: "dash",
            },
          },
          {
            x0: 0,
            x1: 1,
            y0: parseFloat(data.fullLoad),
            y1: parseFloat(data.fullLoad),
            type: "line",
            xref: "paper",
            yref: "y",
            line: {
              color: "green",
              width: 0.75,
              dash: "dash",
            },
          },
        ],
        annotations: [
          {
            xref: "paper",
            x: 1,
            y: parseFloat(data.critical),
            xanchor: "left",
            yanchor: "middle",
            text: "Critical",
            showarrow: false,
            font: { color: "red" },
          },
          {
            xref: "paper",
            x: 1,
            y: parseFloat(data.warning),
            xanchor: "left",
            yanchor: "middle",
            text: "Warning",
            showarrow: false,
            font: { color: "green" },
          },
          {
            xref: "paper",
            x: 1,
            y: parseFloat(data.fullLoad),
            xanchor: "left",
            yanchor: "middle",
            text: "Full Load",
            showarrow: false,
            font: { color: "green" },
          },
          {
            x: 1,
            y: 0.92,
            showarrow: false,
            align: "left",
            xanchor: "left",
            borderwidth: 1,
            bordercolor: "gray",
            bgcolor: "#f0f0f0",
            borderpad: 4,
            xref: "paper",
            yref: "y",
            text:
              "Note: <br>Availability Today : " +
              totalHMToday +
              " hours " +
              "<br>Availability All : " +
              Math.round(totalHMNotToday + totalHMToday),
            font: {
              color: "green",
              size: 10,
            },
          },
        ],
        xaxis: { title: "Time", automargin: true, color: "#000" },
        yaxis: { title: "Value", color: "#000" },
        paper_bgcolor: "#efe7e7",
        plot_bgcolor: "#efe7e7",
        font: { family: "Poppins, sans-serif", color: "#28016c" },
      },
      { responsive: true }
    );

    setTimeout(() => {
      const el = document.getElementById("curveChart");
      if (el) Plotly.Plots.resize(el);
    }, 300);
  }

  private movingAverage(arr: number[], windowSize = 20) {
    const out: number[] = [];
    for (let i = 0; i < arr.length; i++) {
      const s = Math.max(0, i - Math.floor(windowSize / 2));
      const e = Math.min(arr.length, i + Math.ceil(windowSize / 2));
      const w = arr.slice(s, e);
      out.push(w.reduce((a, b) => a + b, 0) / w.length);
    }
    return out;
  }

  /** Expose util so UI can build DOM ids */
  domIdFor(key: string) {
    return slug(key);
  }
}
