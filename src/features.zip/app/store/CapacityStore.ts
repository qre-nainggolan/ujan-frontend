// src/app/store/DashboardStore.ts
import { makeAutoObservable, runInAction } from "mobx";
import Plotly from "plotly.js-dist-min";
import agent from "../api/agent";

type ChartType = "gauge10" | "gauge100" | "bar";
type Series = { key: string; label?: string; type?: ChartType };
type Group = { title: string; series: Series[] };
type MillConfig = { groups: Group[] };

type MillCapacityVisual_ = {
  Mill: string;
  Code: string;
  day1: number;
  day2: number;
  day3: number;
  day4: number;
  day5: number;
  day6: number;
  day7: number;
  day8: number;
  day9: number;
  day10: number;
  day11: number;
  day12: number;
  total: number;
  daily_percentage: number;
  total_hours_year: number;
  active_days_year: number;
  yearly_budget_hours: number;
  yearly_percentage: number;
  monthly_percentage: number;
};

const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

export default class CapacityStore {
  seriesStatus = new Map<
    string,
    "normal" | "out-power" | "out-of-range" | "critical"
  >();
  // Define your boundary limits

  // UI
  popupClass = "popup";
  primaryColor = "#0067c1";
  mills = ["PAN", "PSG"] as const;
  activeMill: (typeof this.mills)[number] = "PSG";
  timeLeft = 60;

  private timerId: any = null;

  currentPage = 1;
  pageSize = 50;
  mill = "PSG";
  loading = true;

  machineHours = {
    availability: new Map<string, { today: number; yesterday: number }>(),
    downtime: new Map<
      string,
      {
        yesterday_run: boolean;
        yesterday_breakdown: boolean;
        today_run: boolean;
        today_breakdown: boolean;
      }
    >(),
  };

  // machineHours: Map<string, number> = new Map();
  loadingHours = false;

  constructor() {
    makeAutoObservable(this, {}, { autoBind: true });
  }

  setActiveMill(mill: (typeof this.mills)[number]) {
    this.activeMill = mill;
    this.timeLeft = 60; // reset countdown to one minute
    this.updateCharts();
  }

  openPopup() {
    this.popupClass = "popup-show";
  }

  closePopup() {
    this.popupClass = "popup";
    try {
      Plotly.purge("curveChart");
    } catch {}
  }

  init() {
    this.updateCharts();
    this.startAutoRefresh();
    this.fetchMachineHours(this.activeMill);
  }

  dispose() {
    this.stopAutoRefresh();
    try {
      Plotly.purge("curveChart");
    } catch {}
  }

  private startAutoRefresh() {
    if (this.timerId) return;
    this.timerId = setInterval(() => {
      runInAction(() => {
        if (this.timeLeft <= 1) {
          this.timeLeft = 60;
          this.updateCharts();
        } else {
          this.timeLeft -= 1;
        }
      });
    }, 1000);
  }

  private stopAutoRefresh() {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  async fetchMachineHours(mill: string) {
    this.loadingHours = true;
    try {
      const [resAvail, resDown] = await Promise.all([
        agent.Lora.getMachineHour(mill), // existing availability endpoint
        agent.Lora.getMachineDowntime(mill), // new downtime endpoint
      ]);

      // Expect response like your latest JSON
      const { availability = [] } = resAvail;
      const { downtime = [] } = resDown;

      runInAction(() => {
        this.machineHours.availability.clear();
        this.machineHours.downtime.clear();

        availability.forEach(
          (d: { name: string; today: number; yesterday: number }) => {
            this.machineHours.availability.set(d.name, {
              today: d.today,
              yesterday: d.yesterday,
            });
          }
        );

        downtime.forEach(
          (d: {
            name: string;
            today_run: boolean;
            today_breakdown: boolean;
            yesterday_run: boolean;
            yesterday_breakdown: boolean;
          }) => {
            this.machineHours.downtime.set(d.name, {
              today_run: d.today_run,
              today_breakdown: d.today_breakdown,
              yesterday_run: d.yesterday_run,
              yesterday_breakdown: d.yesterday_breakdown,
            });
          }
        );
      });
    } catch (err) {
      console.error("Error fetching machine hours:", err);
    } finally {
      runInAction(() => {
        this.loadingHours = false;
      });
    }
  }

  data: MillCapacityVisual_[] = [];

  async fetchData(mill_: string, year_: number, month_: number) {
    this.loading = true;
    try {
      await agent.Lora.getMillCapacityVisual(mill_, year_, month_).then(
        (response) => {
          this.data = response.data; // response.data.rows if using { rows, total }
        }
      );
    } catch (err) {
      console.error("err : " + err);
    } finally {
      this.loading = false;
    }
  }

  /** Draw all charts for current mill */
  async updateCharts() {
    // Iterate groups & series
    this.fetchMachineHours(this.activeMill);
    await this.drawGaugeAnimated("visual-card-cbc1", "06007", -1, {});
    await this.drawGaugeAnimated("visual-card-cbc2", "06008", -1, {});
    this.fetchData(this.activeMill, 2025, 11);
  }

  private async drawGaugeAnimated(
    domId: string,
    keyForApi: string,
    targetValue: number,
    obj: any
  ) {
    let latestDate: string | null = null;
    let latestValue: string | null = null;
    let res: any | null = null;

    // Always attempt to get data if targetValue is missing or invalid
    if (targetValue === -1 || isNaN(targetValue)) {
      try {
        res = await agent.Lora.getLatestCBCValue(keyForApi, this.activeMill);
        targetValue = parseFloat(
          (res.validValue || res.validValue !== "") ?? "0"
        );
        latestDate = res.latestDate || null;
        latestValue = res.latestValue || null;
      } catch (err) {
        console.error("Error fetching latest value:", err);
      }
    }

    // Fallbacks if data is still missing
    latestDate = latestDate || null;
    latestValue = latestValue ?? "N/A";

    const el = document.getElementById(domId);
    // const elLatestDate = document.getElementById(`latestDate${domId}`);

    // If DOM not ready yet, retry after a short delay
    if (!el) {
      setTimeout(() => this.drawGaugeAnimated(domId, keyForApi, 80, obj), 200);
      return;
    }

    this.seriesStatus.set(
      keyForApi,
      targetValue > parseFloat(res.warning)
        ? "critical"
        : targetValue > parseFloat(res.fullLoad) ||
          targetValue < parseFloat(res.minimum)
        ? "out-of-range"
        : targetValue === -1 ||
          latestValue === "" ||
          latestValue === "-" ||
          latestValue === "N/A" ||
          isNaN(targetValue)
        ? "out-power"
        : "normal"
    );

    // Safely render the date
    let formattedDate: string;
    if (latestDate) {
      try {
        formattedDate = new Date(latestDate).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "UTC",
        });
      } catch {
        formattedDate = "Invalid Date";
      }
    } else {
      formattedDate = "No Data";
    }

    // elLatestDate.innerHTML = `${formattedDate} - ${latestValue}`;

    // Draw the gauge if not already present
    if (!(el as any).data) {
      const data = [
        {
          type: "indicator",
          mode: "gauge+number",
          value: targetValue,
          gauge: {
            axis: {
              range: [res.minimum, res.critical],
              tickwidth: 1,
              tickcolor: "darkgray",
            },
            bar: { color: "green" },
            steps: [
              { range: [res.minimum, res.power], color: "#f4f4f4" },
              { range: [res.power, res.fullLoad], color: "#A9D76E" },
              { range: [res.fullLoad, res.warning], color: "#F5F5" },
            ],
          },
        },
      ];

      const layout = {
        margin: { t: 5, r: 30, l: 25, b: 5 },
        paper_bgcolor: "rgba(0,0,0,0.1)",
        font: { color: "black", family: "Poppins" },
      };

      Plotly.newPlot(el as any, data, layout, { displayModeBar: false });
    }

    const currentValue = ((el as any).data?.[0]?.value ?? 0) as number;
    this.animateGauge(el, currentValue, targetValue, 600, 20);

    this.togglePanelIcon(
      el,
      targetValue > parseFloat(res.warning)
        ? "critical"
        : targetValue > parseFloat(res.fullLoad) ||
          targetValue < parseFloat(res.minimum)
        ? "alert"
        : targetValue === -1 ||
          latestValue === "" ||
          latestValue === "-" ||
          latestValue === "N/A" ||
          isNaN(targetValue)
        ? "out-power"
        : "normal"
    );
  }

  private insertNullsForPlotly(
    data: any,
    timeKey: any,
    valueKey: any,
    gapMinutes = 10
  ) {
    const result = [];
    const gapThresholdMs = gapMinutes * 60 * 1000;

    for (let i = 0; i < data.results.length; i++) {
      const current = data.results[i];
      result.push(current);

      const next = data.results[i + 1];
      if (next) {
        const t1: any = new Date(current[timeKey]);
        const t2: any = new Date(next[timeKey]);

        if (t2 - t1 > gapThresholdMs) {
          // Insert null value to break the line
          result.push({
            ...next,
            [valueKey]: null,
          });
        }
      }
    }

    return result;
  }

  private animateGauge(
    el: HTMLElement,
    from: number,
    to: number,
    duration: number,
    steps: number
  ) {
    const interval = duration / steps;
    let frame = 0;
    const stepFn = () => {
      frame++;
      const progress = frame / steps;
      const value = from + (to - from) * progress;
      Plotly.restyle(el as any, { value }, [0]);
      if (frame < steps) setTimeout(stepFn, interval);
    };
    stepFn();
  }

  private togglePanelIcon(el: HTMLElement, isAlert: string) {
    const panel = el.closest(".panel__preview-content");
    if (!panel) return;
    const icon = panel.querySelector(".panel__icon");

    if (!icon) return;

    if (isAlert === "alert") {
      icon.classList.add("panel__icon--alert");
      icon.classList.remove("panel__icon--out-power");
      icon.classList.remove("panel__icon--critical");
    } else if (isAlert === "critical") {
      icon.classList.add("panel__icon--critical");
      icon.classList.remove("panel__icon--out-power");
      icon.classList.remove("panel__icon--alert");
    } else if (isAlert === "out-power") {
      icon.classList.add("panel__icon--out-power");
      icon.classList.remove("panel__icon--alert");
      icon.classList.remove("panel__icon--critical");
    } else {
      icon.classList.remove("panel__icon--alert");
      icon.classList.remove("panel__icon--out-power");
      icon.classList.remove("panel__icon--critical");
    }
  }

  /** Curve popup (preview) */
  async plotPreviewCurveForKey(key: string, machineName: string) {
    const data = await agent.Lora.getCurrentGraph(
      this.activeMill,
      "2025-06-01",
      "2025-06-30",
      key
    );

    const processed = this.insertNullsForPlotly(data, "M", "R", 2);

    const x = processed.map((d: any) => d.M);
    const yRaw = processed.map((d: any) => d.R);
    const ySmooth = this.movingAverage(yRaw, 10);

    const totalHMToday = data.results[0].HMT;
    const totalHMNotToday = data.results[0].HMT;
    Plotly.newPlot(
      "curveChart",
      [
        {
          x,
          y: yRaw,
          mode: "lines",
          name: "Raw Data",
          line: { color: this.primaryColor, width: 2 },
          type: "scatter",
          connectgaps: false,
        },
        {
          x,
          y: ySmooth,
          mode: "lines",
          name: "Smoothed Curve",
          line: { shape: "spline", color: "#28016c", width: 2.5 },
          type: "scatter",
        },
      ],
      {
        title: {
          text: machineName,
          font: { size: 32, color: this.primaryColor },
        },
        shapes: [
          {
            x0: 0,
            x1: 1,
            y0: parseFloat(data.critical),
            y1: parseFloat(data.critical),
            type: "line",
            xref: "paper",
            yref: "y",
            line: {
              color: "red",
              width: 0.75,
              dash: "dash",
            },
          },
          {
            x0: 0,
            x1: 1,
            y0: parseFloat(data.warning),
            y1: parseFloat(data.warning),
            type: "line",
            xref: "paper",
            yref: "y",
            line: {
              color: "green",
              width: 0.75,
              dash: "dash",
            },
          },
          {
            x0: 0,
            x1: 1,
            y0: parseFloat(data.fullLoad),
            y1: parseFloat(data.fullLoad),
            type: "line",
            xref: "paper",
            yref: "y",
            line: {
              color: "green",
              width: 0.75,
              dash: "dash",
            },
          },
        ],
        annotations: [
          {
            xref: "paper",
            x: 1,
            y: parseFloat(data.critical),
            xanchor: "left",
            yanchor: "middle",
            text: "Critical",
            showarrow: false,
            font: { color: "red" },
          },
          {
            xref: "paper",
            x: 1,
            y: parseFloat(data.warning),
            xanchor: "left",
            yanchor: "middle",
            text: "Warning",
            showarrow: false,
            font: { color: "green" },
          },
          {
            xref: "paper",
            x: 1,
            y: parseFloat(data.fullLoad),
            xanchor: "left",
            yanchor: "middle",
            text: "Full Load",
            showarrow: false,
            font: { color: "green" },
          },
          {
            x: 1,
            y: 0.92,
            showarrow: false,
            align: "left",
            xanchor: "left",
            borderwidth: 1,
            bordercolor: "gray",
            bgcolor: "#f0f0f0",
            borderpad: 4,
            xref: "paper",
            yref: "y",
            text:
              "Note: <br>Availability Today : " +
              totalHMToday +
              " hours " +
              "<br>Availability All : " +
              Math.round(totalHMNotToday + totalHMToday),
            font: {
              color: "green",
              size: 10,
            },
          },
        ],
        xaxis: { title: "Time", automargin: true, color: "#000" },
        yaxis: { title: "Value", color: "#000" },
        paper_bgcolor: "#efe7e7",
        plot_bgcolor: "#efe7e7",
        font: { family: "Poppins, sans-serif", color: "#28016c" },
      },
      { responsive: true }
    );

    setTimeout(() => {
      const el = document.getElementById("curveChart");
      if (el) Plotly.Plots.resize(el);
    }, 300);
  }

  private movingAverage(arr: number[], windowSize = 20) {
    const out: number[] = [];
    for (let i = 0; i < arr.length; i++) {
      const s = Math.max(0, i - Math.floor(windowSize / 2));
      const e = Math.min(arr.length, i + Math.ceil(windowSize / 2));
      const w = arr.slice(s, e);
      out.push(w.reduce((a, b) => a + b, 0) / w.length);
    }
    return out;
  }

  /** Expose util so UI can build DOM ids */
  domIdFor(key: string) {
    return slug(key);
  }
}
