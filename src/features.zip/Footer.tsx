export default function Footer() {
  return (
    <>
      <footer className="layout__footer">&copy; 2025 ANE</footer>
    </>
  );
}
