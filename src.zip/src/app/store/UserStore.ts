import { makeAutoObservable } from "mobx";
import { UserProfile } from "../model/UserProfile";
import { User } from "../model/user";
import { store } from "./store";
import { ListUser } from "../model/ListUser";
import agent from "../api/agent";

export default class UserStore {
  user: User | null = null;
  listUser: ListUser[] = [];
  loadingInitial = false;
  keyword = "";
  status = "";
  loginStatus = false;
  aim = "";
  userId = "";
  dateTime = "";
  UserProfile: UserProfile | null = null;

  detail: UserProfile = {
    nama_User: "",
    userID: "",
    registering: "",
    fingerprint: "",
    expired_Password: "",
    approval_Notes: "",
    lastChange: "",
    password: "",
    user_Profile: ""!,
    retypePassword: "",
    status: "",
    displayName: "",
  };

  constructor() {
    makeAutoObservable(this);
  }

  logout = () => {
    store.commonStore.setToken(null);
    window.localStorage.removeItem("user");
    this.UserProfile = null;
    this.setLoginStatus(false);
  };

  getUserProfile = async () => {
    this.loadingInitial = true;
    try {
      await agent.Account.getUserProfile().then((response) => {
        this.UserProfile = response.data;
      });
      this.loadingInitial = false;

      return this.UserProfile;
    } catch (error) {
      this.loadingInitial = false;
    }
  };

  get loadUserParams() {
    const params = new URLSearchParams();
    params.append("keyword", this.keyword);
    params.append("status", this.status);
    params.append("aim", this.aim);
    params.append("userId", this.userId);
    return params;
  }

  setLoadingInitial = (state: boolean) => {
    this.loadingInitial = state;
  };

  setLoginStatus = (state: boolean) => {
    this.loginStatus = state;
  };
}
