import { createContext, useContext } from "react";
import CommonStore from "./CommonStore";
import UserStore from "./UserStore";

interface Store {
  commonStore: CommonStore;
  UserStore: UserStore;
}

export const store: Store = {
  commonStore: new CommonStore(),
  UserStore: new UserStore(),
};

export const StoreContext = createContext(store);

export function useStore() {
  return useContext(StoreContext);
}
