export interface TRSWBIoT {
  type: number;
  target: string;
  arguments: string[];
  success: string;
  data: string;
  status: string;
  value: string;
  message: string;
}
