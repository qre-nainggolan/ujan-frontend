export interface PostResponse {
  code: string;
  message: string;
  dataPrint: string;
}
