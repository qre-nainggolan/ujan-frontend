import { RouteObject, createBrowserRouter } from "react-router-dom";
import PublicPage from "../../features/PublicPage";
import TestPage from "../../features/TestPage";
import MainPage from "../../features/MainPage";
import Tryout from "../../features/simulation/Tryout";
import Package from "../../features/package/Package";
import QuestionForm from "../../features/admin/QuestionForm";
import QuestionBank from "../../features/transaction/QuestionBank";
import PurchasePackage from "../../features/package/PurchasePackage";
import PackageTest from "../../features/transaction/PackageTest";
import QuestionGrid from "../../features/admin/QuestionGrid";
import PackageGrid from "../../features/admin/PackageGrid";

export const routes: RouteObject[] = [
  {
    path: "/",
    element: <PublicPage />,
  },
  {
    path: "/MainPage",
    element: <MainPage />,
  },
  {
    path: "/Tryout",
    element: <Tryout />,
  },
  {
    path: "/test",
    element: <TestPage />,
  },
  {
    path: "/Package",
    element: <Package />,
  },
  {
    path: "/QuestionForm",
    element: <QuestionForm />,
  },
  {
    path: "/QuestionBank",
    element: <QuestionBank />,
  },
  {
    path: "/PurchasePackage",
    element: <PurchasePackage />,
  },
  {
    path: "/PackageTest",
    element: <PackageTest />,
  },
  {
    path: "/QuestionGrid",
    element: <QuestionGrid />,
  },
  {
    path: "/PackageGrid",
    element: <PackageGrid />,
  },
];

export const router = createBrowserRouter(routes);
