import { Outlet } from "react-router-dom";
import { observer } from "mobx-react-lite";
import "./App.css";

function App() {
  return (
    <>
      <Outlet />
    </>
  );
}
export default observer(App);
