import "../css/style2.css";
import "../css/table.css";
import "../css/grid.css";
import Icons from "../img/sprite.svg"; // Path to your icons.svg

import Plotly from "plotly.js-dist-min";
import { useEffect, useState } from "react";
import agent from "../app/api/agent";
import NavLane from "../NavLane";
import Header from "../Header";
import Footer from "../Footer";
import DataGrid from "./component/DataGrid";

function MainPage() {
  const [popupClass, setPopupclass] = useState("popup");

  const [scoreSummary, setScoreSummary] = useState<any[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  // const [scoreDetail, setScoreDetail] = useState<any[]>([]);

  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalData, setTotalData] = useState(0);
  const [pageSize, setPageSize] = useState(50);

  const scoreColumns = [
    {
      header: "#",
      key: "index",
      render: (_: any, i: number) => i + 1 + (currentPage - 1) * pageSize,
      align: "right" as const,
    },
    {
      header: "Tanggal",
      key: "started_at",
      render: (row: any) =>
        new Date(row.started_at).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "UTC",
        }),
    },
    { header: "Total", key: "total" },
    { header: "Tanggal", key: "total" },
    { header: "Benar", key: "correct" },
    {
      header: "Score",
      key: "correct",
      render: (row: any) => ((row.correct / row.total) * 100).toFixed(1),
    },
  ];

  // const
  useEffect(() => {
    agent.Score.getScoreSummary().then((res) => {
      setScoreSummary(res.data);
    });

    // agent.Score.getScoreDetails().then((res) => {
    //   setScoreDetail(res.data);
    // });

    const drawGaugeAnimated = async (divId: string, targetValue: number) => {
      if (targetValue == -1) {
        await agent.Lora.getLatestValue(divId, "PAN").then((response) => {
          // const data = response.targetValue;
          targetValue = parseFloat(response.latestValue);
        });
        console.log(targetValue);
      }

      const el = document.getElementById(divId);

      if (!el || !(el as any).data) {
        const data = [
          {
            type: "indicator",
            mode: "gauge+number",
            value: targetValue,
            gauge: {
              axis: { range: [0, 100], tickwidth: 1, tickcolor: "darkgray" },
              bar: { color: "green" },
              steps: [
                { range: [0, 40], color: "#f4f4f4" },
                { range: [40, 70], color: "#f9d976" },
                { range: [70, 100], color: "#f55" },
              ],
            },
          },
        ];

        const layout = {
          margin: { t: 25, r: 30, l: 25, b: 30 },
          paper_bgcolor: "#3f51b5",
          font: { color: "#fff", family: "Poppins" },
        };

        Plotly.newPlot(el as any, data, layout, { displayModeBar: false });
        return;
      }

      const currentValue = (el as any).data[0].value || 0;
      const steps = 20;
      const duration = 600;
      const interval = duration / steps;
      let frame = 0;

      const stepFn = () => {
        frame++;
        const progress = frame / steps;
        const interpolatedValue =
          currentValue + (targetValue - currentValue) * progress;
        Plotly.restyle(el as any, { value: interpolatedValue }, [0]);

        if (frame < steps) {
          setTimeout(stepFn, interval);
        }
      };
      stepFn();

      const panel = el.closest(".panel__preview-content");
      if (panel) {
        const icon = panel.querySelector(".panel__icon");
        if (icon) {
          if (targetValue < 30 || targetValue > 90) {
            icon.classList.add("panel__icon--alert");
          } else {
            icon.classList.remove("panel__icon--alert");
          }
        }
      }
    };

    function updateCharts() {
      ["Last_Tryout_1_1", "Last_Tryout_1_2", "Last_Tryout_1_3"].forEach((id) =>
        drawGaugeAnimated(id, -1)
      );

      ["Last_Tryout_1_4"].forEach((id) =>
        drawGaugeAnimated(id, Math.random() * 100)
      );
    }

    updateCharts();

    // Close button and popup logic
    const closeBtn = document.querySelector(".popup__close") as HTMLElement;
    const popup = document.getElementById("popup") as HTMLElement;

    closeBtn?.addEventListener("click", () => {
      setPopupclass("popup");
      Plotly.purge("curveChart");
    });

    window.addEventListener("click", (event) => {
      if (event.target === popup) {
        setPopupclass("popup");
        Plotly.purge("curveChart");
      }
    });

    // Nav toggle click to allow unchecking checkbox manually
    const navToggle = document.getElementById("nav-toggle") as HTMLInputElement;
    const navLabel = document.querySelector(
      "label[htmlFor='nav-toggle']"
    ) as HTMLElement;

    navLabel?.addEventListener("click", () => {
      navToggle.checked = !navToggle.checked;
    });

    const previews = document.querySelectorAll(".panel__preview");
    previews.forEach((preview) => {
      preview.addEventListener("click", () => {
        setPopupclass("popup-show");

        agent.Lora.getCurrentGraph(
          "PAN",
          "2025-06-01",
          "2025-06-30",
          preview?.getAttribute("data-key")!
        )
          .then((data) => {
            const x = data.results.map((d: any) => d.M);
            const yRaw = data.results.map((d: any) => d.R);
            const ySmooth = movingAverage(yRaw, 10);

            const rawTrace = {
              x,
              y: yRaw,
              mode: "lines",
              name: "Raw Data",
              line: { color: "#faa634", width: 2 },
              type: "scatter",
            };

            const smoothTrace = {
              x,
              y: ySmooth,
              mode: "lines",
              name: "Smoothed Curve",
              line: { shape: "spline", color: "#29b6f6", width: 3 },
              type: "scatter",
            };

            Plotly.newPlot(
              "curveChart",
              [rawTrace, smoothTrace],
              {
                title: {
                  text: "" + preview?.getAttribute("data-key")!,
                  font: {
                    size: 32,
                    color: "#faa634",
                  },
                },
                annotations: [
                  {
                    text: "Last Update at " + data.lastUpdate,
                    x: 1,
                    y: 1,
                    xref: "paper",
                    yref: "paper",
                    showarrow: false,
                    font: {
                      size: 12,
                      color: "#fff",
                    },
                    xanchor: "right",
                  },
                ],
                xaxis: { title: "Time", automargin: true, color: "#cccccc" },
                yaxis: { title: "Value", color: "#cccccc" },
                paper_bgcolor: "#162d45",
                plot_bgcolor: "#162d45",
                font: {
                  family: "Poppins, sans-serif",
                  color: "#fff",
                },
              },
              { responsive: true }
            );
          })
          .then(() => {
            setTimeout(() => {
              Plotly.Plots.resize(document.getElementById("curveChart"));
            }, 300);
          })
          .catch((err) => {
            console.error("Failed to load data:", err);
          });
      });
    });

    function movingAverage(arr: number[], windowSize = 20) {
      const smoothed = [];
      for (let i = 0; i < arr.length; i++) {
        const start = Math.max(0, i - Math.floor(windowSize / 2));
        const end = Math.min(arr.length, i + Math.ceil(windowSize / 2));
        const window = arr.slice(start, end);
        const avg = window.reduce((sum, val) => sum + val, 0) / window.length;
        smoothed.push(avg);
      }
      return smoothed;
    }
    // return () => clearInterval(interval);
  }, []);

  return (
    <>
      <div className="layout">
        <Header />
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <h1>Ringkasan Nilai</h1>
            <div className="table-sensor">
              <DataGrid
                data={scoreSummary || []}
                columns={scoreColumns}
                selectedIndex={selectedIndex}
                onRowClick={(_, i) => setSelectedIndex(i)}
                currentPage={currentPage}
                totalPages={totalPages}
                totalRecords={totalData}
                pageSize={pageSize}
                onPageChange={(newPage) => {
                  setCurrentPage(newPage);
                }}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1); // reset to page 1
                }}
              />
            </div>
            <h1>Visual Perkembangan</h1>
            <div className="chart-row">
              <div className="chart-row__label">4 Tryout Terakhir</div>
              <div className="chart-row__charts">
                <div className="panel__preview" data-key="Last_Tryout_1_1">
                  <div className="panel__preview-content">
                    <svg className="panel__icon">
                      <use xlinkHref={`${Icons}#icon-megaphone`}></use>
                    </svg>
                    <span className="panel__summary">1</span>
                    <div id="Last_Tryout_1_1" className="chart-container"></div>
                  </div>
                </div>
                <div className="panel__preview" data-key="Last_Tryout_1_2">
                  <div className="panel__preview-content">
                    <svg className="panel__icon">
                      <use xlinkHref={`${Icons}#icon-calendar`}></use>
                    </svg>
                    <span className="panel__summary">2</span>
                    <div id="Last_Tryout_1_2" className="chart-container"></div>
                  </div>
                </div>
                <div className="panel__preview" data-key="Last_Tryout_1_3">
                  <div className="panel__preview-content">
                    <svg className="panel__icon">
                      <use xlinkHref={`${Icons}#icon-user-check`}></use>
                    </svg>
                    <span className="panel__summary">3</span>
                    <div id="Last_Tryout_1_3" className="chart-container"></div>
                  </div>
                </div>
                <div className="panel__preview" data-key="Last_Tryout_1_4">
                  <div className="panel__preview-content">
                    <svg className="panel__icon">
                      <use xlinkHref={`${Icons}#icon-equalizer`}></use>
                    </svg>
                    <span className="panel__summary">4</span>
                    <div id="Last_Tryout_1_4" className="chart-container"></div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
        <Footer />
        <div id="popup" className={popupClass}>
          <div className="popup__content">
            <span className="popup__close">&times;</span>
            <div id="curveChart" className="popup__chart"></div>
          </div>
        </div>
      </div>
    </>
  );
}

export default MainPage;
