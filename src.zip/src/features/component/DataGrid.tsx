import React, { useMemo, useState, useRef } from "react";
import "../../css/grid.css";

export type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  group?: string;
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left" | "right";
  width?: number;
};

type DataGridProps<T> = {
  data: T[];
  columns: ColumnDefinition<T>[];
  onRowClick?: (row: T, index: number) => void;
  selectedIndex?: number | null;
  currentPage?: number;
  totalPages?: number;
  totalRecords?: number;
  pageSize?: number;
  onPageChange?: (newPage: number) => void;
  onPageSizeChange?: (newSize: number) => void;
};

function DataGrid<T extends object>({
  data,
  columns,
  onRowClick,
  selectedIndex,
  currentPage = 1,
  totalPages = 1,
  totalRecords = 0,
  pageSize = 50,
  onPageChange,
  onPageSizeChange,
}: DataGridProps<T>) {
  const startRecord = (currentPage - 1) * pageSize + 1;
  const endRecord = Math.min(startRecord + pageSize - 1, totalRecords);
  const tableRef = useRef<HTMLTableElement>(null);

  const [columnWidths, setColumnWidths] = useState<{ [index: number]: number }>(
    () =>
      columns.reduce((acc, col, i) => {
        acc[i] = col.width ?? 150;
        return acc;
      }, {} as { [index: number]: number })
  );

  const { stickyLeftMap, stickyRightMap } = useMemo(() => {
    const stickyLeftMap: { [index: number]: number } = {};
    const stickyRightMap: { [index: number]: number } = {};
    let leftOffset = 0;
    let rightOffset = 0;

    columns.forEach((col, idx) => {
      if (col.sticky === "left") {
        stickyLeftMap[idx] = leftOffset;
        leftOffset += columnWidths[idx] ?? 0;
      }
    });

    [...columns].reverse().forEach((col, i) => {
      const realIndex = columns.length - 1 - i;
      if (col.sticky === "right") {
        stickyRightMap[realIndex] = rightOffset;
        rightOffset += columnWidths[realIndex] ?? 0;
      }
    });

    return { stickyLeftMap, stickyRightMap };
  }, [columns, columnWidths]);

  const groupedColumns = useMemo(() => {
    const groups: { label: string; columns: ColumnDefinition<T>[] }[] = [];
    const seen: { [label: string]: number } = {};

    columns.forEach((col) => {
      if (!col.group) return;
      const groupLabel = col.group;
      if (seen[groupLabel] === undefined) {
        seen[groupLabel] = groups.length;
        groups.push({ label: groupLabel, columns: [col] });
      } else {
        groups[seen[groupLabel]].columns.push(col);
      }
    });

    return groups;
  }, [columns]);

  const handleResizeStart = (e: React.MouseEvent, columnIndex: number) => {
    e.preventDefault();
    const startX = e.clientX;
    const startWidth = columnWidths[columnIndex];

    const onMouseMove = (moveEvent: MouseEvent) => {
      const newWidth = Math.max(50, startWidth + (moveEvent.clientX - startX));
      setColumnWidths((prev) => ({ ...prev, [columnIndex]: newWidth }));
    };

    const onMouseUp = () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
  };

  return (
    <>
      <div className="table-container">
        <table className="sensor-table" ref={tableRef}>
          <thead>
            {groupedColumns.length > 0 && (
              <tr>
                {groupedColumns.map((group, i) => {
                  const startIdx = columns.findIndex(
                    (col) => col === group.columns[0]
                  );

                  const allStickyLeft = group.columns.every(
                    (col) => col.sticky === "left"
                  );
                  const allStickyRight = group.columns.every(
                    (col) => col.sticky === "right"
                  );

                  const style: React.CSSProperties = {
                    zIndex: 4,
                    top: 0,
                    position: "sticky",
                    backgroundColor: "#005f0a",
                    color: "white",
                    height: "1.65rem",
                  };

                  if (allStickyLeft) {
                    style.left = stickyLeftMap[startIdx];
                    style.width = group.columns.reduce((sum, col) => {
                      const idx = columns.indexOf(col);
                      return sum + columnWidths[idx];
                    }, 0);
                  }

                  if (allStickyRight) {
                    const endIdx = startIdx + group.columns.length - 1;
                    style.right = stickyRightMap[endIdx];
                  }

                  const className = allStickyLeft
                    ? "sticky-col sticky-left group-header"
                    : allStickyRight
                    ? "sticky-col sticky-right group-header"
                    : "group-header";

                  return (
                    <th
                      key={i}
                      colSpan={group.columns.length}
                      className={className}
                      style={style}
                    >
                      {group.label}
                    </th>
                  );
                })}
              </tr>
            )}
            <tr>
              {columns.map((col, idx) => {
                const isGrouped = !!col.group;
                const rowSpan = isGrouped ? undefined : 2;

                const style: React.CSSProperties = {
                  textAlign: col.align || "left",
                  width: columnWidths[idx],
                  minWidth: columnWidths[idx],
                  top: isGrouped ? "3.35rem" : "0",
                  left: col.sticky === "left" ? stickyLeftMap[idx] : undefined,
                  right:
                    col.sticky === "right" ? stickyRightMap[idx] : undefined,
                  zIndex: 5, // make sure it stays above cells
                };

                let className = "";
                if (col.sticky === "left") className = "sticky-col sticky-left";
                else if (col.sticky === "right")
                  className = "sticky-col sticky-right";

                return (
                  <th
                    key={idx}
                    className={className}
                    style={style}
                    rowSpan={rowSpan}
                  >
                    <div className="th-content">
                      <span>{col.header}</span>
                      <div
                        className="resize-handle"
                        onMouseDown={(e) => handleResizeStart(e, idx)}
                      />
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {data && data.length > 0 ? (
              data.map((row, i) => (
                <tr
                  key={i}
                  onClick={() => onRowClick?.(row, i)}
                  className={selectedIndex === i ? "row-selected" : ""}
                >
                  {columns.map((col, j) => {
                    const style: React.CSSProperties = {
                      textAlign: col.align || "left",
                      width: columnWidths[j],
                      minWidth: columnWidths[j],
                      left:
                        col.sticky === "left" ? stickyLeftMap[j] : undefined,
                      right:
                        col.sticky === "right" ? stickyRightMap[j] : undefined,
                    };

                    let className = "";
                    if (col.sticky === "left")
                      className = "sticky-col sticky-left";
                    else if (col.sticky === "right")
                      className = "sticky-col sticky-right";

                    return (
                      <td key={j} className={className} style={style}>
                        {col.render
                          ? col.render(row, i)
                          : (row as any)[col.key]}
                      </td>
                    );
                  })}
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={columns.length}
                  style={{ textAlign: "center", padding: "1rem" }}
                >
                  No data found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {onPageChange && (
        <div className="table-footer">
          <div className="pagination-info">
            <b>
              Showing {startRecord}–{endRecord} of {totalRecords}
            </b>
          </div>
          <div className="pagination">
            <button
              disabled={currentPage === 1}
              onClick={() => onPageChange(1)}
            >
              1st
            </button>
            <button
              disabled={currentPage === 1}
              onClick={() => onPageChange(currentPage - 1)}
            >
              Prev
            </button>
            <span>
              {currentPage} of&nbsp;{totalPages}
            </span>
            <button
              disabled={currentPage === totalPages}
              onClick={() => onPageChange(currentPage + 1)}
            >
              Next
            </button>
            <button
              disabled={currentPage === totalPages}
              onClick={() => onPageChange(totalPages)}
            >
              Last
            </button>
            {onPageSizeChange && (
              <select
                className="selection__input pagination-size"
                value={pageSize}
                onChange={(e) => onPageSizeChange(Number(e.target.value))}
                style={{ marginLeft: "1rem" }}
              >
                {[10, 25, 50, 100].map((size) => (
                  <option key={size} value={size}>
                    Show {size}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>
      )}
    </>
  );
}

export default DataGrid;
