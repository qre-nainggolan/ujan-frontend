import "../../css/style2.css";
import "../../css/card.css";

import { useState, useEffect } from "react";
import NavLane from "../../NavLane";
import Header from "../../Header";
import { useNavigate } from "react-router-dom";

import agent from "../../app/api/agent";

type PackageType = {
  id: string;
  name: string;
  type: string;
  description: string;
  price: number;
  discount: number;
  final_price: number;
  start_date: string;
  end_date: string;
  is_purchased: boolean;
  package_id: boolean;
};

function QuestionBank() {
  const [popupClass] = useState("popup");
  const [packages, setPackages] = useState<PackageType[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    agent.Package.getPurchasedPackage()
      .then((response) => {
        setPackages(response.data);
      })
      .catch((err) => {
        console.error("Failed to load packages", err);
      });
  }, []);

  return (
    <>
      <div className="layout">
        <Header />
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <h1>Paket Belajar Ku..</h1>
            <div className="u-center-text u-margin-bottom-medium">
              <h2 className="heading-secondary">
                Ujian & Latihan Dimana Saja Dengan Gratis
              </h2>
            </div>
            <div className="row2">
              {packages.map((pkg, index) => (
                <div className="card-wrapper" key={pkg.id}>
                  <div className="card">
                    <div className="card__side card__side--front">
                      <div
                        className={`card__picture card__picture--${
                          (index % 3) + 1
                        }`}
                      >
                        &nbsp;
                      </div>
                      <h4 className="card__heading">
                        <span
                          className={`card__heading-span card__heading-span--${
                            (index % 3) + 1
                          }`}
                        >
                          {pkg.name}
                        </span>
                      </h4>
                      <div className="card__details">
                        <ul>
                          {pkg.description.split(". ").map((item, i) => (
                            <li key={i}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    <div
                      className={`card__side card__side--back card__side--back-${
                        (index % 3) + 1
                      }`}
                    >
                      <div className="card__cta">
                        <div className="card__price-box">
                          <p className="card__price-only">Sudah Dibeli</p>
                          <p className="card__price-value">Akses Penuh</p>
                        </div>
                        <a
                          href="#"
                          onClick={() => {
                            navigate(`/PackageTest?for=${pkg.package_id}`);
                          }}
                          className="btn btn--white"
                        >
                          Mulai Latihan →
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </main>
        </div>
        {/* Footer */}
        <footer className="layout__footer">
          &copy; 2025 Digital Transformation
        </footer>
        <div id="popup" className={popupClass}>
          <div className="popup__content">
            <span className="popup__close">&times;</span>
            <div id="curveChart" className="popup__chart"></div>
          </div>
        </div>
      </div>
    </>
  );
}

export default QuestionBank;
