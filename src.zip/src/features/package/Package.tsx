import "../../css/style2.css";
import "../../css/card.css";

import NavLane from "../../NavLane";
import Header from "../../Header";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import agent from "../../app/api/agent";

type PackageType = {
  id: string;
  name: string;
  type: string;
  description: string;
  price: number;
  discount: number;
  final_price: number;
  start_date: string;
  end_date: string;
  is_purchased: boolean;
  package_id: boolean;
};

function Package() {
  const [popupClass] = useState("popup");
  const [packages, setPackages] = useState<PackageType[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    agent.Package.getPackage()
      .then((response) => {
        setPackages(response.data);
      })
      .catch((err) => {
        console.error("Failed to load packages", err);
      });
  }, []);

  return (
    <div className="layout">
      <Header />
      <div className="layout__body">
        <NavLane />
        <main className="layout__main">
          <h1>Packets</h1>
          <div className="u-center-text u-margin-bottom-medium">
            <h2 className="heading-secondary">
              Latihan dengan semakin baik...
            </h2>
          </div>
          <div className="row2">
            {packages.map((pkg, index) => (
              <div className="card-wrapper" key={pkg.id}>
                <div className="card">
                  <div className="card__side card__side--front">
                    <div
                      className={`card__picture card__picture--${
                        (index % 3) + 1
                      }`}
                    >
                      &nbsp;
                    </div>
                    <h4 className="card__heading">
                      <span
                        className={`card__heading-span card__heading-span--${
                          (index % 3) + 1
                        }`}
                      >
                        {pkg.name}
                      </span>
                    </h4>
                    <div className="card__details">
                      <ul>
                        {pkg.description.split(". ").map((item, i) => (
                          <li key={i}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  <div
                    className={`card__side card__side--back card__side--back-${
                      (index % 3) + 1
                    }`}
                  >
                    <div className="card__cta">
                      <div className="card__price-box">
                        {pkg.is_purchased ? (
                          <>
                            <p className="card__price-only">Sudah Dibeli</p>
                            <p className="card__price-value">Akses Penuh</p>
                          </>
                        ) : (
                          <>
                            <p className="card__price-only">
                              Diskon {pkg.discount}% hingga{" "}
                              {new Date(pkg.end_date).toLocaleDateString()}
                            </p>
                            <p className="card__price-value">
                              Rp {pkg.final_price.toLocaleString()}
                            </p>
                          </>
                        )}
                      </div>
                      <a
                        href="#"
                        onClick={() => {
                          navigate(
                            pkg.is_purchased
                              ? `/test?for=${pkg.type}`
                              : `/PurchasePackage?package=${pkg.package_id}`
                          );
                        }}
                        className="btn btn--white"
                      >
                        {pkg.is_purchased
                          ? "Mulai Latihan →"
                          : "Beli Sekarang →"}
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>

      <footer className="layout__footer">
        &copy; 2025 Digital Transformation
      </footer>

      <div id="popup" className={popupClass}>
        <div className="popup__content">
          <span className="popup__close">&times;</span>
          <div id="curveChart" className="popup__chart"></div>
        </div>
      </div>
    </div>
  );
}

export default Package;
