import React from "react";
import "../../css/grid.css";

type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left" | "right"; // NEW
};

type DataGridProps<T> = {
  data: T[];
  columns: ColumnDefinition<T>[];
  onRowClick?: (row: T, index: number) => void;
  selectedIndex?: number | null;
  currentPage?: number;
  totalPages?: number;
  totalRecords?: number;
  pageSize?: number;
  onPageChange?: (newPage: number) => void;
  onPageSizeChange?: (newSize: number) => void;
};

function DataGrid<T extends object>({
  data,
  columns,
  onRowClick,
  selectedIndex,
  currentPage = 1,
  totalPages = 1,
  totalRecords = 0,
  pageSize = 50,
  onPageChange,
  onPageSizeChange,
}: DataGridProps<T>) {
  const startRecord = (currentPage - 1) * pageSize + 1;
  const endRecord = Math.min(startRecord + pageSize - 1, totalRecords);

  return (
    <>
      <div className="table-container">
        <table className="sensor-table">
          <thead>
            <tr>
              {columns.map((col, idx) => (
                <th
                  key={idx}
                  className={
                    col.sticky ? `sticky-col sticky-${col.sticky}` : ""
                  }
                  style={{
                    textAlign: col.align || "left",
                    left: col.sticky === "left" ? `${idx * 120}px` : undefined,
                    right: col.sticky === "right" ? "0px" : undefined,
                  }}
                >
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data && data.length > 0 ? (
              data.map((row, i) => (
                <tr
                  key={i}
                  onClick={() => onRowClick?.(row, i)}
                  className={selectedIndex === i ? "row-selected" : ""}
                >
                  {columns.map((col, j) => (
                    <td
                      key={j}
                      className={
                        col.sticky ? `sticky-col sticky-${col.sticky}` : ""
                      }
                      style={{
                        textAlign: col.align || "left",
                        left:
                          col.sticky === "left" ? `${j * 120}px` : undefined,
                        right: col.sticky === "right" ? "0px" : undefined,
                      }}
                    >
                      {col.render ? col.render(row, i) : (row as any)[col.key]}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={columns.length}
                  style={{ textAlign: "center", padding: "1rem" }}
                >
                  No data found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {onPageChange && (
        <div className="table-footer">
          <div className="pagination-info">
            <b>
              Showing {startRecord}–{endRecord} of {totalRecords}
            </b>
          </div>
          <div className="pagination">
            <button
              disabled={currentPage === 1}
              onClick={() => onPageChange(1)}
            >
              1st
            </button>
            <button
              disabled={currentPage === 1}
              onClick={() => onPageChange(currentPage - 1)}
            >
              Prev
            </button>
            <span>
              {currentPage} of&nbsp;{totalPages}
            </span>
            <button
              disabled={currentPage === totalPages}
              onClick={() => onPageChange(currentPage + 1)}
            >
              Next
            </button>
            <button
              disabled={currentPage === totalPages}
              onClick={() => onPageChange(totalPages)}
            >
              Last
            </button>
            {onPageSizeChange && (
              <select
                className="selection__input pagination-size"
                value={pageSize}
                onChange={(e) => onPageSizeChange(Number(e.target.value))}
                style={{ marginLeft: "1rem" }}
              >
                {[10, 25, 50, 100].map((size) => (
                  <option key={size} value={size}>
                    Show {size}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>
      )}
    </>
  );
}

export default DataGrid;
