import "../../css/style2.css";
import "../../css/form.css";
import "../../css/style_popup.css";
import { useEffect, useState } from "react";
import NavLane from "../../NavLane";
import Footer from "../../Footer";
import Header from "../../Header";
import agent from "../../app/api/agent";
import PopupModal from "../component/PopupModal";
import ConfirmationPopup from "../component/ConfirmationPopup";
import DataGrid from "../component/DataGrid";

type Question_ = {
  Package_ID: string;
  Question: string;
  Question_ID: string;
  Type: string;
  DateCreate: string;
  Answer_Text: string;
  Answer: string;
  Package_Name: string;
  OptionA: string;
  OptionB: string;
  OptionC: string;
  OptionD: string;
  OptionE: string;
  Note: string;
  Image: string;
  Category: string;
  Explanation: string;
};

type ColumnDefinition<T> = {
  key: keyof T | string;
  header: string;
  group?: string; // ✅ NEW: for grouping headers
  render?: (row: T, index: number) => React.ReactNode;
  align?: "left" | "center" | "right";
  sticky?: "left" | "right";
  width?: number;
};

type ListMainPackage_ = {
  Package_ID: string;
  Name: string;
  Type: string;
  Description: string;
};

function getNow(GetSevenAM: string) {
  const now = new Date();
  if (GetSevenAM == "yes") {
    now.setHours(7, 0, 0, 0); // set to 07:00:00
  }
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  const hh = String(now.getHours()).padStart(2, "0");
  const mi = String(now.getMinutes()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
}

function QuestionGrid() {
  const [Package_ID, SetPackage_ID] = useState("");
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [startDate, setStartDate] = useState(getNow("yes"));
  const [endDate, setEndDate] = useState(getNow(""));
  const [data, setData] = useState<Question_[] | null>(null);

  const [ListMainPackage, SetListMainPackage] = useState<ListMainPackage_[]>(
    []
  );
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalData, setTotalData] = useState(0);
  const [pageSize, setPageSize] = useState(50);

  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const [showModal, setShowModal] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  const [formData, setFormData] = useState<Question_>();
  const questionColumns: ColumnDefinition<Question_>[] = [
    {
      header: "#",
      key: "row_index",
      group: "Meta",
      render: (_: Question_, i: number) => i + 1 + (currentPage - 1) * pageSize,
      align: "right",
      width: 80,
      sticky: "left",
    },
    {
      header: "Paket",
      key: "Package_Name",
      group: "Meta",
      width: 160,
      sticky: "left",
    },
    {
      header: "Pertanyaan",
      key: "Question",

      width: 240,
    },
    // Single (non-grouped) columns start here
    {
      header: "Tester",
      key: "Question",
      width: 140,
    },
    {
      header: "ABDC 1",
      key: "Question",
      width: 140,
    },
    {
      header: "ABDC 2",
      key: "Question",
      width: 140,
    },
    {
      header: "ABDC 3",
      key: "abdc3",
      width: 140,
    },
    {
      header: "ABDC 4",
      key: "abdc4",
      width: 140,
    },
    {
      header: "ABDC 5",
      key: "abdc5",
      width: 140,
    },
    {
      header: "ABDC 6",
      key: "abdc6",
      width: 140,
    },
    {
      header: "ABDC 7",
      key: "abdc7",
      width: 140,
    },
    {
      header: "ABDC 8",
      key: "abdc8",
      width: 140,
    },
    {
      header: "ABDC 9",
      key: "abdc9",
      width: 140,
    },
    {
      header: "ABDC 10",
      key: "abdc10",
      width: 140,
    },
    {
      header: "Jawaban",
      key: "Answer_Text",
      width: 200,
    },
    {
      header: "Time",
      key: "DateCreate",
      width: 160,
      render: (row: Question_) =>
        new Date(row.DateCreate).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "UTC",
        }),
    },
  ];

  function formatDateForBackend(dateStr: string) {
    const date = new Date(dateStr);
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    const hh = String(date.getHours()).padStart(2, "0");
    const ii = String(date.getMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${ii}`;
  }

  const sanitizeText = (text: string) => {
    return text
      .replace(/'/g, "&#39;")
      .replace(/"/g, "&quot;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  };

  const submitQuestion = async () => {
    // simple validation
    if (!formData?.Package_ID || !formData?.Question || !formData.Answer) {
      alert("Semua field wajib diisi");
      return;
    }

    // sanitize all text fields
    const sanitizedForm = {
      ...formData,
      Question_ID: parseInt(formData?.Question_ID),
      Package_ID: sanitizeText(formData?.Package_ID),
      Question: sanitizeText(formData?.Question),
      Type: sanitizeText(formData?.Type),
      OptionA: sanitizeText(formData?.OptionA),
      OptionB: sanitizeText(formData?.OptionB),
      OptionC: sanitizeText(formData?.OptionC),
      OptionD: sanitizeText(formData?.OptionD),
      OptionE: sanitizeText(formData?.OptionE),
      Note: "",
      Image: "",
      Category: "",
      Explanation: "",
    };

    try {
      await agent.Package.submitQuestion(sanitizedForm)
        .then(() => {
          setFormData({
            Package_ID: "",
            Question_ID: "",
            Question: "",
            Type: "",
            OptionA: "",
            OptionB: "",
            OptionC: "",
            OptionD: "",
            OptionE: "",
            Answer_Text: "",
            Explanation: "",
            Package_Name: "",
            Answer: "",
            DateCreate: "",
            Note: "",
            Image: "",
            Category: "",
          });
          setShowConfirmation(false);
          alert("Pertanyaan berhasil ditambahkan!");
        })
        .catch((err) =>
          console.error("Error saat menambahkan pertanyaan ke database", err)
        );
    } catch (error) {
      console.error("Error submitting question:", error);
      alert("Gagal menambahkan pertanyaan. Silakan coba lagi.");
    }
  };

  const fetchData = async (
    package_ID_: string,
    category_: string,
    startDate_: string,
    endDate_: string,
    currentPage_: number,
    pageSize_: number
  ) => {
    try {
      await agent.Package.getPaginatedQuestionList(
        package_ID_,
        category_,
        formatDateForBackend(startDate_),
        formatDateForBackend(endDate_),
        currentPage_,
        pageSize_
      ).then((response) => {
        setData(response.data); // response.data.rows if using { rows, total }
        setTotalPages(Math.ceil(response.total / pageSize)); // if backend returns total count
        setTotalData(response.total);
      });
    } catch (err) {
      console.error("err : " + err);
    }
  };

  useEffect(() => {
    fetchData(Package_ID, "", startDate, endDate, currentPage, pageSize);
  }, [Package_ID, "", startDate, endDate]);

  useEffect(() => {
    try {
      agent.Package.getListMainPackage().then((response) => {
        SetListMainPackage(response.data);
      });
    } catch (err) {
      console.error("err : " + err);
    }
  }, []);

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;

    setFormData((prev) => {
      if (!prev) return prev; // or throw an error or set a default object
      return { ...prev, [name]: value };
    });
  };

  return (
    <>
      <div className="layout">
        <Header />
        {/* Main layout body: nav + content */}
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <div className="sensor-container">
              <div className="controls">
                <select
                  value={Package_ID}
                  onChange={(e) => {
                    SetPackage_ID(e.target.value);
                    console.log(e.target.value);
                  }}
                  className="selection__input"
                >
                  <option value="">Pilihan Paket</option>
                  {ListMainPackage.map((row) => (
                    <option value={row.Package_ID + ""}>{row.Name}</option>
                  ))}
                </select>
                <input
                  type="datetime-local"
                  className="selection__input"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
                <input
                  type="datetime-local"
                  className="selection__input"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
                <div style={{ marginLeft: ".25rem" }}>
                  <button
                    onClick={() => {
                      fetchData(
                        Package_ID,
                        "",
                        startDate,
                        endDate,
                        0,
                        pageSize
                      );
                    }}
                  >
                    Refresh
                  </button>
                  <button
                    style={{ marginLeft: ".25rem" }}
                    onClick={() => {
                      setIsEditMode(false);
                      setFormData({
                        Package_ID: "",
                        Question_ID: "",
                        Question: "",
                        Type: "",
                        OptionA: "",
                        OptionB: "",
                        OptionC: "",
                        OptionD: "",
                        OptionE: "",
                        Answer_Text: "",
                        Explanation: "",
                        Package_Name: "",
                        Answer: "",
                        DateCreate: "",
                        Note: "",
                        Image: "",
                        Category: "",
                      });
                      setShowModal(true);
                    }}
                  >
                    Add
                  </button>
                  <button
                    onClick={() => {
                      if (selectedIndex === null || !data)
                        return alert("Select a row first");
                      const selected = data[selectedIndex];
                      setIsEditMode(true);
                      setFormData({
                        Package_ID: selected.Package_ID,
                        Question_ID: selected.Question_ID,
                        Question: selected.Question,
                        Type: selected.Type,
                        OptionA: selected.OptionA, // map actual data if available
                        OptionB: selected.OptionB,
                        OptionC: selected.OptionC,
                        OptionD: selected.OptionD,
                        OptionE: selected.OptionE,
                        Answer_Text: selected.Answer_Text,
                        Explanation: selected.Explanation,
                        Answer: selected.Answer,
                        Package_Name: "",
                        DateCreate: "",
                        Note: "",
                        Image: "",
                        Category: "",
                      });
                      setShowModal(true);
                    }}
                    disabled={selectedIndex === null}
                    style={{ marginLeft: "0.5rem" }}
                  >
                    Edit
                  </button>
                </div>
              </div>
              <DataGrid
                data={data || []}
                columns={questionColumns}
                selectedIndex={selectedIndex}
                onRowClick={(_, i) => setSelectedIndex(i)}
                currentPage={currentPage}
                totalPages={totalPages}
                totalRecords={totalData}
                pageSize={pageSize}
                onPageChange={(newPage) => {
                  fetchData(
                    Package_ID,
                    "",
                    startDate,
                    endDate,
                    newPage,
                    pageSize
                  );
                  setCurrentPage(newPage);
                }}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1); // reset to page 1
                  fetchData(Package_ID, "", startDate, endDate, 1, newSize);
                }}
              />
            </div>
          </main>
        </div>
        <Footer />
        <PopupModal
          title={isEditMode ? "Edit Soal" : "Tambah Soal"}
          show={showModal}
          onClose={() => setShowModal(false)}
        >
          <form className="question-form">
            <div className="form-row">
              <div>
                <label>Paket</label>
                <select
                  name="Package_ID"
                  className="selection__input"
                  value={formData?.Package_ID}
                  onChange={handleChange}
                  required
                >
                  <option value="">-- Pilih Paket --</option>
                  {ListMainPackage.map((row) => (
                    <option value={row.Package_ID + ""} key={row.Package_ID}>
                      {row.Name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label>Type</label>
                <input
                  name="Type"
                  className="selection__input"
                  value={formData?.Type}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            <label>Text Pertanyaan</label>
            <textarea
              name="Question"
              className="selection__input"
              value={formData?.Question}
              onChange={handleChange}
              required
            />
            <div className="form-row">
              <div>
                <label>Option A</label>
                <input
                  name="OptionA"
                  className="selection__input"
                  value={formData?.OptionA}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label>Option B</label>
                <input
                  name="OptionB"
                  className="selection__input"
                  value={formData?.OptionB}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="form-row">
              <div>
                <label>Option C</label>
                <input
                  name="OptionC"
                  className="selection__input"
                  value={formData?.OptionC}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label>Option D</label>
                <input
                  name="OptionD"
                  className="selection__input"
                  value={formData?.OptionD}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="form-row">
              <div>
                <label>Option E</label>
                <input
                  name="OptionE"
                  className="selection__input"
                  value={formData?.OptionE}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label>Correct Answer</label>
                <div className="radio-group">
                  {["A", "B", "C", "D", "E"].map((option) => (
                    <label key={option} className="radio-option">
                      <input
                        type="radio"
                        name="Answer"
                        value={option}
                        checked={formData?.Answer === option}
                        onChange={handleChange}
                        required
                      />
                      <span className="custom-radio" />
                      {option}
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="form-row">
              <button
                className="btn btn--green"
                type="button"
                onClick={() => {
                  console.log("Check");
                  setShowConfirmation(true);
                }}
              >
                {isEditMode ? "Update" : "Submit"}
              </button>
              <button
                className="btn btn--green"
                type="button"
                onClick={() => setShowModal(false)}
              >
                Cancel
              </button>
            </div>
          </form>
        </PopupModal>
        <ConfirmationPopup
          show={showConfirmation}
          onCancel={() => setShowConfirmation(false)}
          onConfirm={submitQuestion}
        />
      </div>
    </>
  );
}
export default QuestionGrid;
