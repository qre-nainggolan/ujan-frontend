import "../../css/style2.css";

import "../../css/form.css";
import "../../css/style_popup.css";
import { useEffect, useRef, useState } from "react";
import NavLane from "../../NavLane";
import Footer from "../../Footer";
import Header from "../../Header";
import agent from "../../app/api/agent";

type PackageType = {
  id: string;
  name: string;
  type: string;
  description: string;
  price: number;
  discount: number;
  final_price: number;
  start_date: string;
  end_date: string;
  is_purchased: boolean;
  package_id: string;
};

function QuestionForm() {
  const popupRef = useRef<HTMLDivElement>(null);
  const [Packages, SetPackages] = useState<PackageType[]>([]);
  const pos = useRef({
    x: 0, // last translateX
    y: 0, // last translateY
    startX: 0,
    startY: 0,
    dragging: false,
  });

  const [ShowPreview, SetShowPreview] = useState(false);
  const [popupConfirmationClass, setPopupConfirmationclass] = useState(
    "popup__confirmation"
  );
  const [SelectedPackage, SetSelectedPackage] = useState("");

  const handlePreviewSubmit = () => {
    const matched = Packages.findIndex(
      (a) => a.package_id === formData.package_id
    );

    SetSelectedPackage(Packages[matched]?.name || "");

    setPopupConfirmationclass("popup__confirmation-show");
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!pos.current.dragging || !popupRef.current) return;

      const dx = e.clientX - pos.current.startX;
      const dy = e.clientY - pos.current.startY;

      const newX = pos.current.x + dx;
      const newY = pos.current.y + dy;

      popupRef.current.style.transform = `translate(${newX}px, ${newY}px)`;
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (!pos.current.dragging) return;

      const dx = e.clientX - pos.current.startX;
      const dy = e.clientY - pos.current.startY;

      pos.current.x += dx;
      pos.current.y += dy;
      pos.current.dragging = false;
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, []);

  useEffect(() => {
    agent.Package.getPackage()
      .then((response) => {
        SetPackages(response.data);
      })
      .catch((err) => {
        console.error("Failed to load packages", err);
      });
  }, []);

  const [formData, setFormData] = useState({
    question: "",
    type: "",
    category: "",
    optionA: "",
    optionB: "",
    optionC: "",
    optionD: "",
    optionE: "",
    answer: "",
    explanation: "",
    note: "",
    package_id: "",
    image: "",
  });

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const sanitizeText = (text: string) => {
    return text
      .replace(/'/g, "&#39;")
      .replace(/"/g, "&quot;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  };

  const submitQuestion = async (e: React.FormEvent) => {
    e.preventDefault();

    // simple validation
    if (!formData.package_id || !formData.question || !formData.answer) {
      alert("Semua field wajib diisi");
      return;
    }

    // sanitize all text fields
    const sanitizedForm = {
      ...formData,
      question: sanitizeText(formData.question),
      type: sanitizeText(formData.type),
      category: sanitizeText(formData.category),
      optionA: sanitizeText(formData.optionA),
      optionB: sanitizeText(formData.optionB),
      optionC: sanitizeText(formData.optionC),
      optionD: sanitizeText(formData.optionD),
      optionE: sanitizeText(formData.optionE),
      explanation: sanitizeText(formData.explanation),
      note: sanitizeText(formData.note),
      image: sanitizeText(formData.image),
    };

    try {
      await agent.Package.submitQuestion(sanitizedForm)
        .then(() => {
          setFormData({
            question: "",
            type: "",
            category: "",
            optionA: "",
            optionB: "",
            optionC: "",
            optionD: "",
            optionE: "",
            answer: "",
            explanation: "",
            note: "",
            package_id: "",
            image: "",
          });
          setPopupConfirmationclass("popup__confirmation");
          alert("Pertanyaan berhasil ditambahkan!");
        })
        .catch((err) =>
          console.error("Error saat menambahkan pertanyaan ke database", err)
        );
    } catch (error) {
      console.error("Error submitting question:", error);
      alert("Gagal menambahkan pertanyaan. Silakan coba lagi.");
    }
  };

  return (
    <>
      <div className="layout">
        <Header />
        {/* Main layout body: nav + content */}
        <div className="layout__body">
          <NavLane />
          <main className="layout__main">
            <form className="question-form">
              <h1>Tambah Soal</h1>
              <label>Paket</label>
              <select
                name="package_id"
                className="form__input"
                value={formData.package_id}
                onChange={handleChange}
                required
              >
                <option value="">-- Pilih Paket --</option>
                {Packages.map((pkg) => (
                  <option key={pkg.package_id} value={pkg.package_id}>
                    {pkg.name} ({pkg.type})
                  </option>
                ))}
              </select>

              <label>Text Pertanyaan</label>
              <textarea
                name="question"
                className="form__input"
                value={formData.question}
                onChange={handleChange}
                required
              />

              <label>Type</label>
              <input
                name="type"
                className="form__input"
                value={formData.type}
                onChange={handleChange}
                required
              />

              <label>Option A</label>
              <input
                name="optionA"
                className="form__input"
                value={formData.optionA}
                onChange={handleChange}
              />

              <label>Option B</label>
              <input
                name="optionB"
                className="form__input"
                value={formData.optionB}
                onChange={handleChange}
              />

              <label>Option C</label>
              <input
                name="optionC"
                className="form__input"
                value={formData.optionC}
                onChange={handleChange}
              />

              <label>Option D</label>
              <input
                name="optionD"
                className="form__input"
                value={formData.optionD}
                onChange={handleChange}
              />

              <label>Option E</label>
              <input
                name="optionE"
                className="form__input"
                value={formData.optionE}
                onChange={handleChange}
              />

              <label>Correct Answer</label>
              <div className="radio-group">
                {["A", "B", "C", "D", "E"].map((option) => (
                  <label key={option} className="radio-option">
                    <input
                      type="radio"
                      name="answer"
                      value={option}
                      checked={formData.answer === option}
                      onChange={handleChange}
                      required
                    />
                    <span className="custom-radio" />
                    {option}
                  </label>
                ))}
              </div>
              <label>Pembahasan</label>
              <textarea
                name="explanation"
                className="form__input"
                value={formData.explanation}
                onChange={handleChange}
              />
              <label>Catatan Tambahan</label>
              <textarea
                name="note"
                className="form__input"
                value={formData.note}
                onChange={handleChange}
              />

              <label>Link Gambar</label>
              <input
                name="image"
                className="form__input"
                value={formData.image}
                onChange={handleChange}
              />

              <button type="button" onClick={handlePreviewSubmit}>
                Kirim Pertanyaan
              </button>
            </form>
            {ShowPreview && (
              <>
                <div
                  className="popup__confirmation__overlay"
                  onMouseDown={(e) => {
                    // Prevent closing if clicking on the popup content
                    if (e.target === e.currentTarget) {
                      SetShowPreview(false);
                    }
                  }}
                ></div>
                <div
                  className="popup__confirmation__content fancy"
                  ref={popupRef}
                >
                  <h3 className="popup__confirmation__title">Pratinjau Soal</h3>

                  <div className="popup__confirmation__text preview">
                    <p>
                      <strong>Soal:</strong> {formData.question}
                    </p>
                    <ul>
                      {[
                        "optionA",
                        "optionB",
                        "optionC",
                        "optionD",
                        "optionE",
                      ].map((opt) => (
                        <li key={opt}>
                          <strong>{opt.slice(-1)}:</strong>{" "}
                          {formData[opt as keyof typeof formData]}
                        </li>
                      ))}
                    </ul>
                    <p>
                      <strong>Jawaban:</strong> {formData.answer}
                    </p>
                    {formData.image && (
                      <img
                        src={formData.image}
                        alt="preview"
                        style={{
                          maxWidth: "100%",
                          borderRadius: "8px",
                          marginTop: "1rem",
                        }}
                      />
                    )}
                    <div
                      style={{
                        marginTop: "1.5rem",
                        display: "flex",
                        gap: "1rem",
                        justifyContent: "flex-end",
                      }}
                    >
                      <button
                        className="btn btn--white"
                        onClick={() => SetShowPreview(false)}
                      >
                        Batal
                      </button>
                      <button className="btn btn--green">
                        Konfirmasi Kirim
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </main>
        </div>
        <Footer />
        <div className={popupConfirmationClass}>
          <div
            className="popup__confirmation__overlay"
            onClick={() => setPopupConfirmationclass("popup__confirmation")}
          ></div>
          <div
            className="popup__confirmation__content fancy"
            ref={popupRef}
            onMouseDown={(e) => {
              pos.current.dragging = true;
              pos.current.startX = e.clientX;
              pos.current.startY = e.clientY;
            }}
          >
            <h3 className="popup__confirmation__title">Pratinjau Soal</h3>

            <div className="popup__confirmation__text">
              <p>
                <strong>Paket:</strong> {SelectedPackage}
              </p>
              <p>
                <strong>Soal:</strong> {formData.question}
              </p>
              <ul>
                {["optionA", "optionB", "optionC", "optionD", "optionE"].map(
                  (opt) => (
                    <li key={opt} style={{ textDecoration: "none" }}>
                      <strong>{opt.slice(-1)}:</strong>{" "}
                      {formData[opt as keyof typeof formData]}
                    </li>
                  )
                )}
              </ul>
              <p>
                <strong>Jawaban:</strong> {formData.answer}
              </p>
              {formData.image && (
                <img
                  src={formData.image}
                  alt="preview"
                  style={{
                    maxWidth: "100%",
                    borderRadius: "8px",
                    marginTop: "1rem",
                  }}
                />
              )}
              <div className="popup__confirmation__buttons">
                <button
                  className="popup__confirmation__button popupConfirmation__button--cancel"
                  onClick={() =>
                    setPopupConfirmationclass("popup__confirmation")
                  }
                >
                  ❌ Cancel
                </button>
                <button
                  className="popup__confirmation__button popupConfirmation__button--yes"
                  onClick={submitQuestion}
                >
                  ✅ Yes, submit
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default QuestionForm;
